import {
  UIConfiguration,
  HeaderMapping,
  WhatsAppTemplate,
  ColumnConfig,
  SectionDetailConfig,
  WorkflowRule,
  Ticket,
  Contractor,
  CoverageArea,
  RootCauseCategory
} from '../types';

export const DEFAULT_COLUMNS: ColumnConfig[] = [
  { key: 'woNumber', label: 'WO Number', visible: true, order: 1, width: 140, sticky: 'left', format: 'code', sortable: true, filterable: true },
  { key: 'date', label: 'Date', visible: true, order: 2, width: 110, format: 'date', sortable: true },
  { key: 'idCustomer', label: 'Customer ID', visible: true, order: 3, width: 130, format: 'code', sortable: true, filterable: true },
  { key: 'customerName', label: 'Customer Name', visible: true, order: 4, width: 180, sortable: true, filterable: true },
  { key: 'customerPhone', label: 'Phone', visible: true, order: 5, width: 140, format: 'phone' },
  { key: 'area', label: 'Area', visible: true, order: 6, width: 120, sortable: true, filterable: true },
  { key: 'clusterName', label: 'Cluster', visible: true, order: 7, width: 140, sortable: true, filterable: true },
  { key: 'slotTime', label: 'Slot Time', visible: true, order: 8, width: 130, sortable: true },
  { key: 'ticketCategory', label: 'Category', visible: true, order: 9, width: 130, format: 'badge', sortable: true, filterable: true },
  { key: 'contactorName', label: 'Contractor', visible: true, order: 10, width: 140, sortable: true, filterable: true },
  { key: 'installerName', label: 'Installer', visible: true, order: 11, width: 140, sortable: true, filterable: true },
  { key: 'statusWOAgent', label: 'Status Agent', visible: true, order: 12, width: 130, format: 'status_agent', sortable: true, filterable: true },
  { key: 'statusWOInstaller', label: 'Status Installer', visible: true, order: 13, width: 140, format: 'status_installer', sortable: true, filterable: true },
  { key: 'statusWhatsApp', label: 'WhatsApp Status', visible: true, order: 14, width: 160, format: 'status_wa', sortable: true, filterable: true },
  { key: 'fdtCode', label: 'FDT Code', visible: false, order: 15, width: 110, format: 'code' },
  { key: 'fatCode', label: 'FAT Code', visible: false, order: 16, width: 110, format: 'code' },
  { key: 'streetName', label: 'Street Address', visible: false, order: 17, width: 220, wrapText: true },
  { key: 'remarksWOInstaller', label: 'Installer Remarks', visible: false, order: 18, width: 200, wrapText: true },
  { key: 'agentId', label: 'Agent ID', visible: false, order: 19, width: 100 },
  { key: 'dateUpload', label: 'Date Uploaded', visible: false, order: 20, width: 120, format: 'date' },
  { key: 'fileName', label: 'Source File', visible: false, order: 21, width: 150 },
  { key: 'updatedAt', label: 'Last Updated', visible: true, order: 22, width: 130, format: 'date', sortable: true },
  { key: 'actions', label: 'Actions', visible: true, order: 23, width: 140, sticky: 'right', align: 'center' }
];

export const DEFAULT_DETAIL_SECTIONS: SectionDetailConfig[] = [
  {
    id: 'customer_info',
    title: 'Customer Information',
    visible: true,
    order: 1,
    fields: [
      { key: 'customerName', label: 'Customer Name', visible: true, order: 1, width: 'half' },
      { key: 'idCustomer', label: 'Customer ID', visible: true, order: 2, width: 'half', isReadOnly: true },
      { key: 'customerPhone', label: 'Phone Number', visible: true, order: 3, width: 'half' },
      { key: 'area', label: 'Service Area', visible: true, order: 4, width: 'half' },
      { key: 'clusterName', label: 'Cluster / Complex', visible: true, order: 5, width: 'half' },
      { key: 'streetName', label: 'Primary Address', visible: true, order: 6, width: 'full' },
      { key: 'streetAlternatif', label: 'Alternative Address / Landmark', visible: true, order: 7, width: 'full' }
    ]
  },
  {
    id: 'work_order_info',
    title: 'Work Order Information',
    visible: true,
    order: 2,
    fields: [
      { key: 'woNumber', label: 'WO Number', visible: true, order: 1, width: 'half', isReadOnly: true },
      { key: 'ticketCategory', label: 'Category / Service', visible: true, order: 2, width: 'half' },
      { key: 'slotTime', label: 'Scheduled Slot Time', visible: true, order: 3, width: 'half' },
      { key: 'date', label: 'Appointment Date', visible: true, order: 4, width: 'half' },
      { key: 'ticketNumber', label: 'Ticket Reference', visible: true, order: 5, width: 'half' },
      { key: 'fileName', label: 'Import Source File', visible: true, order: 6, width: 'half' }
    ]
  },
  {
    id: 'location_technical',
    title: 'Location & Technical Information',
    visible: true,
    order: 3,
    fields: [
      { key: 'fdtCode', label: 'FDT Code', visible: true, order: 1, width: 'half' },
      { key: 'fatCode', label: 'FAT Code', visible: true, order: 2, width: 'half' },
      { key: 'agentId', label: 'Originating Agent ID', visible: true, order: 3, width: 'half' },
      { key: 'dateUpload', label: 'Upload Date', visible: true, order: 4, width: 'half' }
    ]
  },
  {
    id: 'dispatch_assignment',
    title: 'Dispatch & Personnel Assignment',
    visible: true,
    order: 4,
    fields: [
      { key: 'contactorName', label: 'Contractor Vendor', visible: true, order: 1, width: 'third' },
      { key: 'leaderName', label: 'Assigned Leader / Korlap', visible: true, order: 2, width: 'third' },
      { key: 'installerName', label: 'Assigned Installer / Teknisi', visible: true, order: 3, width: 'third' }
    ]
  },
  {
    id: 'status_reports',
    title: 'Status & Execution Reports',
    visible: true,
    order: 5,
    fields: [
      { key: 'statusWOAgent', label: 'Agent Status', visible: true, order: 1, width: 'half' },
      { key: 'statusWOInstaller', label: 'Installer Field Status', visible: true, order: 2, width: 'half' },
      { key: 'remarksAgent', label: 'Agent Dispatch Notes', visible: true, order: 3, width: 'full' },
      { key: 'remarksWOInstaller', label: 'Installer Field Remarks', visible: true, order: 4, width: 'full' }
    ]
  },
  {
    id: 'whatsapp_confirmation',
    title: 'WhatsApp Customer Confirmation',
    visible: true,
    order: 6,
    fields: [
      { key: 'statusWhatsApp', label: 'Confirmation Status', visible: true, order: 1, width: 'half', isReadOnly: true },
      { key: 'waLastOpenedAt', label: 'Last Opened in WhatsApp', visible: true, order: 2, width: 'half', isReadOnly: true },
      { key: 'waConfirmedAt', label: 'Confirmed At', visible: true, order: 3, width: 'half', isReadOnly: true },
      { key: 'waConfirmedBy', label: 'Confirmed By Officer', visible: true, order: 4, width: 'half', isReadOnly: true },
      { key: 'waConfirmationNotes', label: 'Customer Confirmation Notes', visible: true, order: 5, width: 'full' }
    ]
  }
];

export const DEFAULT_UI_CONFIG: UIConfiguration = {
  id: 'default_config_v1',
  version: 1,
  updatedAt: new Date().toISOString(),
  updatedBy: 'System Administrator',
  global: {
    appName: 'MoraJaws',
    logoIcon: 'Truck',
    primaryColor: 'indigo', // 'blue' | 'indigo' | 'emerald' | 'slate' | 'violet'
    themeMode: 'light',
    fontScale: 'medium',
    density: 'comfortable',
    contentWidth: 'contained',
    borderRadius: 'medium',
    buttonStyle: 'solid',
    tableStyle: 'bordered',
    sidebarState: 'expanded',
    sidebarCollapsed: false,
    toolbarPosition: 'top',
    modalSize: 'large'
  },
  ticketsTable: {
    columns: DEFAULT_COLUMNS,
    density: 'comfortable',
    rowsPerPage: 10,
    showEmptyFields: false,
    activePresetId: 'preset_default',
    presets: [
      {
        id: 'preset_default',
        name: 'Standard Dispatch View',
        description: 'Balanced column layout for general ticket monitoring and routing',
        columns: DEFAULT_COLUMNS,
        density: 'comfortable',
        rowsPerPage: 10
      },
      {
        id: 'preset_compact_dispatch',
        name: 'Compact Operations',
        description: 'High-density grid focused on installer assignments and work status',
        columns: DEFAULT_COLUMNS.map(col => ({
          ...col,
          visible: ['woNumber', 'customerName', 'area', 'installerName', 'slotTime', 'statusWOInstaller', 'statusWhatsApp', 'actions'].includes(col.key),
          width: col.key === 'woNumber' ? 120 : col.width
        })),
        density: 'compact',
        rowsPerPage: 20
      },
      {
        id: 'preset_customer_contact',
        name: 'Customer & WhatsApp Confirmation',
        description: 'Prioritizes customer contact, address, slot time and WhatsApp status',
        columns: DEFAULT_COLUMNS.map(col => ({
          ...col,
          visible: ['woNumber', 'customerName', 'customerPhone', 'slotTime', 'clusterName', 'installerName', 'statusWhatsApp', 'actions'].includes(col.key)
        })),
        density: 'comfortable',
        rowsPerPage: 15
      },
      {
        id: 'preset_technical',
        name: 'Technical & Infrastructure',
        description: 'Focuses on FDT, FAT, category, and technical completion',
        columns: DEFAULT_COLUMNS.map(col => ({
          ...col,
          visible: ['woNumber', 'area', 'clusterName', 'fdtCode', 'fatCode', 'ticketCategory', 'installerName', 'statusWOInstaller', 'actions'].includes(col.key)
        })),
        density: 'compact',
        rowsPerPage: 15
      }
    ]
  },
  toolbar: {
    buttons: [
      { id: 'btn_refresh', label: 'Refresh', icon: 'RotateCw', visible: true, order: 1, group: 'secondary' },
      { id: 'btn_import_wo', label: 'Import WO', icon: 'FileSpreadsheet', visible: true, order: 2, group: 'primary', roleRequired: ['super_admin', 'dispatch'] },
      { id: 'btn_export', label: 'Export Data', icon: 'Download', visible: true, order: 3, group: 'secondary' },
      { id: 'btn_view_presets', label: 'View Presets', icon: 'LayoutGrid', visible: true, order: 4, group: 'secondary' },
      { id: 'btn_table_settings', label: 'Customize Table', icon: 'SlidersHorizontal', visible: true, order: 5, group: 'secondary' },
      { id: 'btn_archive_toggle', label: 'Archived Tickets', icon: 'Archive', visible: true, order: 6, group: 'more_menu' },
      { id: 'btn_bulk_assign', label: 'Bulk Assign', icon: 'UserCheck', visible: true, order: 7, group: 'more_menu', roleRequired: ['super_admin', 'dispatch', 'leader'] }
    ],
    showSearch: true,
    showFilters: true,
    showExport: true,
    showImport: true,
    showArchiveToggle: true,
    showDensityToggle: true
  },
  ticketDetail: {
    showEmptyFields: false,
    sections: DEFAULT_DETAIL_SECTIONS
  },
  pageLayouts: {
    dashboard: { sectionOrder: ['kpi_cards', 'quick_actions', 'contractor_distribution', 'recent_wos'], columns: 4 },
    tickets: { layout: 'table', filterPosition: 'top' },
    importWO: { showInstructions: true },
    detail: { layout: 'two_column' }
  },
  device: {
    mode: 'auto',
    android: {
      layoutType: 'cards',
      touchTargetSize: 'comfortable',
      showBottomNavigation: true,
      cardDensity: 'comfortable',
      showQuickCall: true,
      showQuickWhatsApp: true,
      showQuickDetail: true,
      highContrastBadges: true,
      autoCloseSidebarOnNavigate: true
    },
    pc: {
      tableDensity: 'compact',
      stickyColumns: true,
      wideScreenFullWidth: true,
      showInlineFilters: true,
      showBulkToolbar: true,
      actionButtonsLayout: 'inline_icons',
      multiColumnDetail: true
    }
  }
};

export const STANDARD_HEADER_MAPPINGS: HeaderMapping[] = [
  {
    standardField: 'woNumber',
    label: 'WO Number',
    aliases: ['wo number', 'no wo', 'nomor wo', 'wo_number', 'wo id', 'work order number', 'wonumber', 'no. wo'],
    required: true,
    category: 'core'
  },
  {
    standardField: 'idCustomer',
    label: 'Customer ID',
    aliases: ['id customer', 'customer id', 'no pelanggan', 'id pelanggan', 'cust id', 'id_customer', 'customerid'],
    required: true,
    category: 'customer'
  },
  {
    standardField: 'customerName',
    label: 'Customer Name',
    aliases: ['customer name', 'nama customer', 'nama pelanggan', 'customer_name', 'name', 'nama'],
    required: true,
    category: 'customer'
  },
  {
    standardField: 'customerPhone',
    label: 'Customer Phone',
    aliases: ['customer phone', 'no hp', 'no telp', 'nomor telepon', 'customer_phone', 'phone', 'contact', 'telepon', 'mobile'],
    required: true,
    category: 'customer'
  },
  {
    standardField: 'date',
    label: 'Date',
    aliases: ['date', 'tanggal', 'tgl', 'date wo', 'appointment date', 'tanggal wo'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'slotTime',
    label: 'Slot Time',
    aliases: ['slot time', 'slot_time', 'waktu kunjungan', 'jadwal', 'slot', 'appointment time', 'jam kunjungan'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'contactorName',
    label: 'Contractor Name',
    aliases: ['contactor name', 'contractor name', 'nama kontraktor', 'kategori kontraktor', 'kategori vendor', 'kategori mitra', 'kat kontraktor', 'vendor', 'mitra', 'kontraktor', 'contractor'],
    required: false,
    category: 'assignment'
  },
  {
    standardField: 'area',
    label: 'Area',
    aliases: ['area', 'wilayah', 'regional', 'kota', 'city', 'zone', 'region'],
    required: false,
    category: 'location'
  },
  {
    standardField: 'installerName',
    label: 'Installer Name',
    aliases: ['installer name', 'teknisi', 'nama teknisi', 'installer', 'petugas', 'installer_name', 'technician'],
    required: false,
    category: 'assignment'
  },
  {
    standardField: 'clusterName',
    label: 'Cluster Name',
    aliases: ['cluster name', 'cluster', 'nama cluster', 'perumahan', 'komplek', 'cluster_name'],
    required: false,
    category: 'location'
  },
  {
    standardField: 'fdtCode',
    label: 'FDT Code',
    aliases: ['fdt code', 'fdt', 'kode fdt', 'fdt_code'],
    required: false,
    category: 'technical'
  },
  {
    standardField: 'fatCode',
    label: 'FAT Code',
    aliases: ['fat code', 'fat', 'kode fat', 'fat_code'],
    required: false,
    category: 'technical'
  },
  {
    standardField: 'ticketCategory',
    label: 'Ticket Category',
    aliases: ['ticket category', 'kategori tiket', 'category', 'jenis tiket', 'jenis wo', 'tipe wo', 'tipe tiket'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'statusWOInstaller',
    label: 'Status WO Installer',
    aliases: ['status wo installer', 'status installer', 'status teknisi', 'installer status', 'progres installer'],
    required: false,
    category: 'status'
  },
  {
    standardField: 'remarksWOInstaller',
    label: 'Remarks WO Installer',
    aliases: ['remarks wo installer', 'remarks installer', 'catatan teknisi', 'remarks', 'keterangan teknisi'],
    required: false,
    category: 'status'
  },
  {
    standardField: 'fileName',
    label: 'File Name',
    aliases: ['file name', 'nama file', 'source file', 'file_name'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'dateUpload',
    label: 'Date Upload',
    aliases: ['date upload', 'tgl upload', 'tanggal upload', 'uploaded date', 'date_upload'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'agentId',
    label: 'Agent ID',
    aliases: ['agent id', 'id agent', 'agent', 'petugas agent', 'agent_id'],
    required: false,
    category: 'core'
  },
  {
    standardField: 'streetName',
    label: 'Street Name',
    aliases: ['street name', 'alamat', 'street', 'alamat pelanggan', 'address', 'street_name'],
    required: false,
    category: 'location'
  },
  {
    standardField: 'streetAlternatif',
    label: 'Street Alternatif',
    aliases: ['street alternatif', 'alamat alternatif', 'patokan', 'landmark', 'alamat cadangan'],
    required: false,
    category: 'location'
  }
];

export const DEFAULT_WHATSAPP_TEMPLATES: WhatsAppTemplate[] = [
  {
    id: 'tpl_schedule_confirmation',
    name: 'Konfirmasi Jadwal Kunjungan Teknisi',
    description: 'Pesan standar konfirmasi jadwal kedatangan teknisi dan alamat pemasangan kepada pelanggan',
    category: 'Konfirmasi Jadwal Kunjungan',
    messageBody: `Halo Bapak/Ibu {{customer_name}},

Kami menginformasikan bahwa Work Order Anda telah dijadwalkan dengan detail berikut:

Nomor WO: {{wo_number}}
Nomor Pelanggan: {{customer_id}}
Jadwal Kunjungan: {{slot_time}}
Alamat: {{street_name}}
Cluster: {{cluster_name}}
Teknisi: {{installer_name}}
Kontraktor: {{contractor_name}}

Mohon konfirmasi apakah Bapak/Ibu bersedia menerima kunjungan teknisi pada jadwal tersebut.

Balas "YA" untuk konfirmasi, atau hubungi kami jika ingin mengajukan perubahan jadwal (reschedule).

Terima kasih.
Tim Dispatch & Customer Support`,
    availableVariables: [
      'customer_name',
      'customer_id',
      'customer_phone',
      'wo_number',
      'slot_time',
      'street_name',
      'cluster_name',
      'area',
      'installer_name',
      'contractor_name',
      'ticket_category',
      'date'
    ],
    isDefault: true,
    active: true,
    editableByRole: ['super_admin', 'dispatch', 'leader'],
    createdBy: 'System',
    updatedBy: 'System',
    version: 1,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'tpl_en_route',
    name: 'Teknisi Menuju Lokasi (En Route)',
    description: 'Pemberitahuan bahwa teknisi sedang dalam perjalanan menuju alamat pelanggan',
    category: 'Teknisi Menuju Lokasi',
    messageBody: `Halo Bapak/Ibu {{customer_name}},

Teknisi kami, {{installer_name}} (Mitra: {{contractor_name}}), sedang dalam perjalanan menuju lokasi Anda di {{cluster_name}}, {{area}} untuk pengerjaan WO {{wo_number}}.

Estimasi kedatangan sesuai slot: {{slot_time}}.
Mohon pastikan ada perwakilan di rumah saat teknisi tiba.

Jika ada kendala arah lokasi, teknisi dapat menghubungi nomor ini.

Terima kasih.`,
    availableVariables: [
      'customer_name',
      'customer_id',
      'wo_number',
      'slot_time',
      'cluster_name',
      'area',
      'installer_name',
      'contractor_name'
    ],
    isDefault: false,
    active: true,
    editableByRole: ['super_admin', 'dispatch', 'leader'],
    createdBy: 'System',
    updatedBy: 'System',
    version: 1,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'tpl_reschedule_offer',
    name: 'Penjadwalan Ulang (Reschedule Request)',
    description: 'Template untuk menawarkan opsi jadwal baru bila pelanggan berhalangan',
    category: 'Perubahan Jadwal',
    messageBody: `Halo Bapak/Ibu {{customer_name}},

Menindaklanjuti permohonan reschedule untuk WO {{wo_number}}, saat ini kami menyediakan pilihan slot waktu kunjungan berikutnya.

Mohon informasikan ketersediaan waktu Bapak/Ibu di antara opsi berikut atau ajukan tanggal alternatif yang diinginkan.

Nomor Pelanggan: {{customer_id}}
Cluster: {{cluster_name}}

Kami siap membantu agar pengerjaan dapat berjalan lancar. Terima kasih.`,
    availableVariables: [
      'customer_name',
      'customer_id',
      'wo_number',
      'cluster_name',
      'slot_time'
    ],
    isDefault: false,
    active: true,
    editableByRole: ['super_admin', 'dispatch'],
    createdBy: 'System',
    updatedBy: 'System',
    version: 1,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'tpl_completion_check',
    name: 'Konfirmasi Penyelesaian Pemasangan',
    description: 'Verifikasi kepuasan dan status penyelesaian instalasi dari pelanggan',
    category: 'Konfirmasi Penyelesaian',
    messageBody: `Halo Bapak/Ibu {{customer_name}},

Pengerjaan WO {{wo_number}} oleh teknisi {{installer_name}} telah dilaporkan selesai.

Mohon pastikan layanan sudah dapat digunakan dengan baik. Apabila ada pertanyaan atau catatan perbaikan, silakan sampaikan kepada kami.

Terima kasih atas kerja sama Bapak/Ibu.
Salam hangat, Dispatch Management`,
    availableVariables: [
      'customer_name',
      'wo_number',
      'installer_name',
      'slot_time'
    ],
    isDefault: false,
    active: true,
    editableByRole: ['super_admin', 'dispatch'],
    createdBy: 'System',
    updatedBy: 'System',
    version: 1,
    lastUpdated: new Date().toISOString()
  },
  {
    id: 'tpl_installer_assignment',
    name: 'Penugasan WO Teknisi Lapangan (Assignment Notification)',
    description: 'Pesan notifikasi resmi penugasan Work Order dari Leader/Korlap langsung ke nomor WhatsApp teknisi installer',
    category: 'Penugasan Teknisi Lapangan',
    messageBody: `Halo Rekan Teknisi {{installer_name}},

Ada penugasan Work Order baru untuk Anda dari Korlap ({{leader_name}} - {{contractor_name}}):

📌 Detail Work Order:
- No. WO: {{wo_number}}
- Kategori: {{ticket_category}}
- Tanggal Kunjungan: {{appointment_date}}
- Slot Waktu: {{slot_time}}

📍 Lokasi Pelanggan:
- Nama: {{customer_name}}
- No. Kontak Pelanggan: {{customer_phone}}
- Alamat: {{street_name}}
- Patokan: {{street_alternatif}}
- Cluster: {{cluster_name}}
- Area: {{area}}

🔧 Data Jaringan:
- OLT/FDT: {{fdt_code}}
- FAT Code: {{fat_code}}

Harap segera konfirmasi penerimaan tugas melalui Portal Teknisi Lapangan atau balas pesan ini jika siap meluncur.
Terima kasih, selamat bertugas!`,
    availableVariables: [
      'installer_name',
      'installer_phone',
      'leader_name',
      'contractor_name',
      'wo_number',
      'ticket_category',
      'appointment_date',
      'slot_time',
      'customer_name',
      'customer_phone',
      'street_name',
      'street_alternatif',
      'cluster_name',
      'area',
      'fdt_code',
      'fat_code'
    ],
    isDefault: false,
    active: true,
    editableByRole: ['super_admin', 'dispatch', 'leader'],
    createdBy: 'System',
    updatedBy: 'System',
    version: 1,
    lastUpdated: new Date().toISOString()
  }
];

export const DEFAULT_WORKFLOW_RULES: WorkflowRule[] = [
  {
    id: 'wf_assign_prepare_wa',
    name: 'Otomatis Siapkan URL WhatsApp Saat Installer Ditugaskan',
    description: 'Ketika teknisi berhasil di-assign ke tiket, sistem langsung menyiapkan URL konfirmasi WhatsApp dengan template aktif.',
    trigger: 'installer_assigned',
    conditions: [
      { field: 'customerPhone', operator: 'is_not_empty' }
    ],
    actions: [
      { type: 'prepare_whatsapp', templateId: 'tpl_schedule_confirmation', targetStatus: 'ready' },
      { type: 'log_event' }
    ],
    enabled: true,
    executionCount: 14,
    lastExecutedAt: new Date().toISOString()
  },
  {
    id: 'wf_slot_time_changed',
    name: 'Reset Konfirmasi Jika Slot Waktu Berubah',
    description: 'Bila slot waktu kunjungan diubah, set status WhatsApp kembali menjadi Ready dan siapkan pesan update.',
    trigger: 'slot_time_changed',
    conditions: [],
    actions: [
      { type: 'update_wa_status', targetStatus: 'ready' },
      { type: 'prepare_whatsapp', templateId: 'tpl_schedule_confirmation' },
      { type: 'log_event' }
    ],
    enabled: true,
    executionCount: 3,
    lastExecutedAt: new Date(Date.now() - 3600000).toISOString()
  },
  {
    id: 'wf_new_import_validation',
    name: 'Notifikasi & Validasi Saat Tiket Baru Diimpor',
    description: 'Validasi otomatis kelengkapan nomor telepon pelanggan dan cluster saat tiket diimpor.',
    trigger: 'ticket_imported',
    conditions: [],
    actions: [
      { type: 'log_event' }
    ],
    enabled: true,
    executionCount: 42,
    lastExecutedAt: new Date().toISOString()
  }
];

export const INITIAL_SAMPLE_TICKETS: Ticket[] = [
  {
    id: 't-101',
    woNumber: 'WO-2026-8801',
    workOrderNumber: 'WO-2026-8801',
    idCustomer: '7399330',
    customerId: '7399330',
    ticketNumber: 'TCK-55410',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'New Install FTTH',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-042',
    customerName: 'Budi Hartono',
    endUserName: 'Budi Hartono',
    customerPhone: '081288992211',
    customerContact1: '081288992211',
    customerPhoneNormalized: '6281288992211',
    streetName: 'Jl. Melati Indah No. 42 RT 04 RW 02',
    streetAlternatif: 'Dekat Pos Satpam Blok B',
    clusterName: 'Grand Melati Residence',
    area: 'Jakarta Selatan',
    fdtCode: 'FDT-JS-012',
    fatCode: 'FAT-JS-012-04',
    slotTime: '09:00 - 11:00 WIB',
    ticketCategory: 'New Installation FTTH',
    initialTicketCategory: 'New Installation FTTH',
    contactorName: 'PT Mitra Jaringan Solusi',
    contractorName: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    leaderName: 'Hendra Gunawan',
    corlapName: 'Hendra Gunawan',
    installerName: 'Andi Saputra',
    statusWOAgent: 'Assigned',
    statusWOInstaller: 'Assigned',
    statusWhatsApp: 'ready',
    distributionStatus: 'distributed',
    distributionNotes: 'Berhasil didistribusikan ke PT Mitra Jaringan Solusi (Hendra Gunawan)',
    remarksWOInstaller: 'Material kabel dan modem siap dibawa',
    remarksAgent: 'Prioritas pelanggan baru minta pagi',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-17T09:15:00Z',
    updatedBy: 'Dispatch Officer'
  },
  {
    id: 't-102',
    woNumber: 'WO-2026-8802',
    workOrderNumber: 'WO-2026-8802',
    idCustomer: '7399331',
    customerId: '7399331',
    ticketNumber: 'TCK-55411',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'Relocation',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-042',
    customerName: 'Siti Rahmawati',
    endUserName: 'Siti Rahmawati',
    customerPhone: '085712345678',
    customerContact1: '085712345678',
    customerPhoneNormalized: '6285712345678',
    streetName: 'Komplek Permata Hijau Kav. 18',
    streetAlternatif: 'Pagar abu-abu seberang taman',
    clusterName: 'Permata Hijau 2',
    area: 'Jakarta Barat',
    fdtCode: 'FDT-JB-008',
    fatCode: 'FAT-JB-008-02',
    slotTime: '13:00 - 15:00 WIB',
    ticketCategory: 'Relocation & Dismantle',
    initialTicketCategory: 'Relocation & Dismantle',
    contactorName: 'PT Kencana Solusindo',
    contractorName: 'PT Kencana Solusindo',
    contractorId: 'c-2',
    leaderName: 'Bambang Sudiro',
    corlapName: 'Bambang Sudiro',
    installerName: 'Dedi Kurniawan',
    statusWOAgent: 'Assigned',
    statusWOInstaller: 'En Route',
    statusWhatsApp: 'opened_in_whatsapp',
    distributionStatus: 'distributed',
    distributionNotes: 'Berhasil didistribusikan ke PT Kencana Solusindo (Bambang Sudiro)',
    waLastOpenedAt: '2026-10-17T11:20:00Z',
    remarksWOInstaller: 'Menuju lokasi pelanggan',
    remarksAgent: 'Pastikan cek optical power di FAT',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-17T11:20:00Z',
    updatedBy: 'Hendra Gunawan'
  },
  {
    id: 't-103',
    woNumber: 'WO-2026-8803',
    workOrderNumber: 'WO-2026-8803',
    idCustomer: '7399332',
    customerId: '7399332',
    ticketNumber: 'TCK-55412',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'Upgrade Speed',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-019',
    customerName: 'Agus Setiawan',
    endUserName: 'Agus Setiawan',
    customerPhone: '081399887766',
    customerContact1: '081399887766',
    customerPhoneNormalized: '6281399887766',
    streetName: 'Jl. Danau Sunter Utara No. 89',
    streetAlternatif: 'Ruko samping Bank Mandiri',
    clusterName: 'Sunter Indah',
    area: 'Jakarta Utara',
    fdtCode: 'FDT-JU-034',
    fatCode: 'FAT-JU-034-09',
    slotTime: '10:00 - 12:00 WIB',
    ticketCategory: 'Upgrade Bandwidth + Mesh',
    initialTicketCategory: 'Upgrade Bandwidth + Mesh',
    contactorName: 'PT Mitra Jaringan Solusi',
    contractorName: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    leaderName: 'Hendra Gunawan',
    corlapName: 'Hendra Gunawan',
    installerName: 'Rizky Pratama',
    statusWOAgent: 'Resolved',
    statusWOInstaller: 'Completed',
    statusWhatsApp: 'confirmed',
    distributionStatus: 'distributed',
    distributionNotes: 'Berhasil didistribusikan ke PT Mitra Jaringan Solusi',
    waLastOpenedAt: '2026-10-17T09:40:00Z',
    waConfirmedAt: '2026-10-17T09:55:00Z',
    waConfirmedBy: 'Dispatch Officer',
    waConfirmationNotes: 'Pelanggan membalas YA bersedia dikunjungi pukul 10:00 WIB',
    remarksWOInstaller: 'Instalasi selesai, speedtest 100 Mbps simetris OK',
    remarksAgent: 'Pelanggan puas dengan layanan',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-17T12:05:00Z',
    updatedBy: 'Rizky Pratama'
  },
  {
    id: 't-104',
    woNumber: 'WO-2026-8804',
    workOrderNumber: 'WO-2026-8804',
    idCustomer: '7399333',
    customerId: '7399333',
    ticketNumber: 'TCK-55413',
    date: '2026-10-19',
    appointmentDate: '2026-10-19',
    appointmentType: 'New Install FTTH',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-055',
    customerName: 'Dewi Lestari',
    endUserName: 'Dewi Lestari',
    customerPhone: '087811223344',
    customerContact1: '087811223344',
    customerPhoneNormalized: '6287811223344',
    streetName: 'Cluster Victoria Blok D1 No. 5',
    streetAlternatif: '',
    clusterName: 'Victoria Riverside',
    area: 'Tangerang Selatan',
    fdtCode: 'FDT-TS-005',
    fatCode: 'FAT-TS-005-01',
    slotTime: '15:00 - 17:00 WIB',
    ticketCategory: 'New Installation FTTH',
    initialTicketCategory: 'New Installation FTTH',
    contactorName: 'PT Cipta Fiber Nusantara',
    contractorName: 'PT Cipta Fiber Nusantara',
    leaderName: 'Ahmad Fauzi',
    corlapName: 'Ahmad Fauzi',
    installerName: '',
    statusWOAgent: 'Pending',
    statusWOInstaller: 'Unassigned',
    statusWhatsApp: 'not_prepared',
    distributionStatus: 'distributed',
    distributionNotes: 'Telah terdistribusi ke PT Cipta Fiber Nusantara, menunggu teknisi',
    remarksWOInstaller: '',
    remarksAgent: 'Menunggu penugasan teknisi dari Korlap',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-17T08:30:00Z',
    updatedBy: 'System'
  },
  {
    id: 't-105',
    woNumber: 'WO-2026-8805',
    workOrderNumber: 'WO-2026-8805',
    idCustomer: '7399334',
    customerId: '7399334',
    ticketNumber: 'TCK-55414',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'Maintenance',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-019',
    customerName: 'Ir. Hendra Wijaya',
    endUserName: 'Ir. Hendra Wijaya',
    customerPhone: '08112345678',
    customerContact1: '08112345678',
    customerPhoneNormalized: '628112345678',
    streetName: 'Jl. Margonda Raya No. 12',
    streetAlternatif: 'Belakang Starbucks',
    clusterName: 'Margonda Residence',
    area: 'Depok',
    fdtCode: 'FDT-DPK-021',
    fatCode: 'FAT-DPK-021-03',
    slotTime: '11:00 - 13:00 WIB',
    ticketCategory: 'Maintenance / LOS Red Light',
    initialTicketCategory: 'Maintenance / LOS Red Light',
    contactorName: 'PT Kencana Solusindo',
    contractorName: 'PT Kencana Solusindo',
    contractorId: 'c-2',
    leaderName: 'Bambang Sudiro',
    corlapName: 'Bambang Sudiro',
    installerName: 'Eko Prasetyo',
    statusWOAgent: 'In Progress',
    statusWOInstaller: 'On Site',
    statusWhatsApp: 'reschedule_requested',
    distributionStatus: 'distributed',
    distributionNotes: 'Didistribusikan ke PT Kencana Solusindo',
    waLastOpenedAt: '2026-10-17T09:10:00Z',
    waConfirmationNotes: 'Pelanggan minta ganti jam karena sedang ada rapat hingga siang',
    remarksWOInstaller: 'Sedang menunggu kepulangan pelanggan atau jadwal pengganti',
    remarksAgent: 'Koordinasikan dengan Korlap Bambang',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-17T10:00:00Z',
    updatedBy: 'Bambang Sudiro'
  },
  {
    id: 't-106',
    woNumber: 'WO-2026-8806',
    workOrderNumber: 'WO-2026-8806',
    idCustomer: '7399335',
    customerId: '7399335',
    ticketNumber: 'TCK-55415',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'New Install FTTH',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-042',
    customerName: 'Rian Hidayat',
    endUserName: 'Rian Hidayat',
    customerPhone: '081299112233',
    customerContact1: '081299112233',
    customerPhoneNormalized: '6281299112233',
    streetName: 'Jl. Fatmawati Raya No. 15 RT 02 RW 05',
    streetAlternatif: 'Samping Bank BCA Fatmawati',
    clusterName: 'Pondok Labu Indah',
    area: 'Jakarta Selatan',
    fdtCode: 'FDT-JS-012',
    fatCode: 'FAT-JS-012-07',
    slotTime: '13:00 - 15:00 WIB',
    ticketCategory: 'New Installation FTTH',
    initialTicketCategory: 'New Installation FTTH',
    contactorName: 'PT Mitra Jaringan Solusi',
    contractorName: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    leaderName: 'Hendra Gunawan',
    corlapName: 'Hendra Gunawan',
    installerName: 'Andi Saputra',
    statusWOAgent: 'Resolved',
    statusWOInstaller: 'Completed',
    statusWhatsApp: 'confirmed',
    distributionStatus: 'distributed',
    distributionNotes: 'Tuntas dikerjakan oleh Andi Saputra',
    remarksWOInstaller: 'Instalasi ONT Huawei berhasil tuntas, redaman stabil -18.7 dBm',
    remarksAgent: 'Pelanggan telah menandatangani BAST fisik',
    technicalReport: {
      id: 'rep-106',
      ticketId: 't-106',
      mainCategory: 'Fiber Optic FTTH',
      rootCause: 'Normal Installation',
      workResult: 'Success',
      technicalDescription: 'Pemasangan kabel drop core 95m dan konfigurasi ONT lancar',
      correctiveAction: 'Selesai tanpa kendala',
      opticalPowerDbm: '-18.7',
      photoBeforeUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600&auto=format&fit=crop&q=80',
      photoAfterUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80',
      submittedBy: 'Andi Saputra',
      submittedAt: '2026-10-18T14:45:00Z'
    },
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-18T14:45:00Z',
    updatedBy: 'Andi Saputra'
  },
  {
    id: 't-107',
    woNumber: 'WO-2026-8807',
    workOrderNumber: 'WO-2026-8807',
    idCustomer: '7399336',
    customerId: '7399336',
    ticketNumber: 'TCK-55416',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'Maintenance',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-019',
    customerName: 'Maya Anggraini',
    endUserName: 'Maya Anggraini',
    customerPhone: '081377889900',
    customerContact1: '081377889900',
    customerPhoneNormalized: '6281377889900',
    streetName: 'Jl. Cilandak Barat No. 8A',
    streetAlternatif: 'Komplek Asri Kav 3, pagar hitam',
    clusterName: 'Cilandak Townhouse',
    area: 'Jakarta Selatan',
    fdtCode: 'FDT-JS-009',
    fatCode: 'FAT-JS-009-02',
    slotTime: '11:00 - 13:00 WIB',
    ticketCategory: 'Maintenance / LOS Sinyal Drop',
    initialTicketCategory: 'Maintenance / LOS Sinyal Drop',
    contactorName: 'PT Mitra Jaringan Solusi',
    contractorName: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    leaderName: 'Hendra Gunawan',
    corlapName: 'Hendra Gunawan',
    installerName: 'Andi Saputra',
    statusWOAgent: 'In Progress',
    statusWOInstaller: 'Pending Technical',
    statusWhatsApp: 'reschedule_requested',
    distributionStatus: 'distributed',
    distributionNotes: 'Pelanggan minta reschedule',
    remarksWOInstaller: 'Pelanggan sedang di luar kota hingga besok, minta reschedule ke tanggal 19 Okt pagi',
    remarksAgent: 'Jadwal ulang telah dicatat, koordinasikan ulang',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-18T11:15:00Z',
    updatedBy: 'Andi Saputra'
  },
  {
    id: 't-108',
    woNumber: 'WO-2026-8808',
    workOrderNumber: 'WO-2026-8808',
    idCustomer: '7399337',
    customerId: '7399337',
    ticketNumber: 'TCK-55417',
    date: '2026-10-18',
    appointmentDate: '2026-10-18',
    appointmentType: 'New Install FTTH',
    dateUpload: '2026-10-17 08:30',
    fileName: 'WEBCC_WO_EXPORT_OCT17.csv',
    agentId: 'AGT-055',
    customerName: 'Farhan Ramadhan',
    endUserName: 'Farhan Ramadhan',
    customerPhone: '081766554433',
    customerContact1: '081766554433',
    customerPhoneNormalized: '6281766554433',
    streetName: 'Jl. Lebak Bulus Raya No. 22 RT 01 RW 04',
    streetAlternatif: 'Seberang Apotek Kimia Farma',
    clusterName: 'Lebak Bulus Asri',
    area: 'Jakarta Selatan',
    fdtCode: 'FDT-JS-015',
    fatCode: 'FAT-JS-015-08',
    slotTime: '15:00 - 17:00 WIB',
    ticketCategory: 'New Installation FTTH',
    initialTicketCategory: 'New Installation FTTH',
    contactorName: 'PT Mitra Jaringan Solusi',
    contractorName: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    leaderName: 'Hendra Gunawan',
    corlapName: 'Hendra Gunawan',
    installerName: 'Andi Saputra',
    statusWOAgent: 'Cancelled',
    statusWOInstaller: 'Failed / Cancelled',
    statusWhatsApp: 'cancelled',
    distributionStatus: 'distributed',
    distributionNotes: 'Batal karena kendala infrastruktur tiang',
    remarksWOInstaller: 'FAT-JS-015-08 penuh (16/16 port over capacity), pelanggan menolak menunggu perluasan jaringan',
    remarksAgent: 'Tiket dibatalkan atas konfirmasi pelanggan',
    isArchived: false,
    createdAt: '2026-10-17T08:30:00Z',
    updatedAt: '2026-10-18T15:30:00Z',
    updatedBy: 'Andi Saputra'
  }
];

export const DEFAULT_CONTRACTORS: Contractor[] = [
  {
    id: 'c-1',
    name: 'PT Mitra Jaringan Solusi',
    code: 'MJS',
    coverageAreas: ['Jakarta Selatan', 'Tangerang Selatan'],
    leaderId: 'u-3',
    leaderName: 'Hendra Gunawan',
    phone: '0812-9988-7711',
    email: 'ops@mitrajaringan.co.id',
    active: true,
    createdAt: '2026-01-10T00:00:00Z'
  },
  {
    id: 'c-2',
    name: 'PT Kencana Solusindo',
    code: 'KCS',
    coverageAreas: ['Jakarta Barat', 'Jakarta Utara', 'Depok'],
    leaderId: 'u-5',
    leaderName: 'Bambang Sudiro',
    phone: '0813-8877-6622',
    email: 'dispatch@kencanasolusindo.com',
    active: true,
    createdAt: '2026-01-15T00:00:00Z'
  },
  {
    id: 'c-3',
    name: 'PT Cipta Fiber Nusantara',
    code: 'CFN',
    coverageAreas: ['Tangerang Selatan', 'Tangerang Kota'],
    leaderId: 'u-6',
    leaderName: 'Ahmad Fauzi',
    phone: '0815-7766-5533',
    email: 'operations@ciptafiber.net',
    active: true,
    createdAt: '2026-02-01T00:00:00Z'
  },
  {
    id: 'c-4',
    name: 'PT Surya Telekomunikasi Abadi',
    code: 'STA',
    coverageAreas: ['Jakarta Timur', 'Bekasi'],
    leaderId: 'u-7',
    leaderName: 'Suryadi Pratama',
    phone: '0818-6655-4422',
    email: 'korlap@suryatelekom.co.id',
    active: true,
    createdAt: '2026-02-10T00:00:00Z'
  }
];

export const DEFAULT_COVERAGE_AREAS: CoverageArea[] = [
  {
    id: 'area-1',
    name: 'Jakarta Selatan',
    clusters: ['Grand Melati Residence', 'Taman Asri Blok C', 'Gandaria Hills', 'Cilandak Baru', 'Pondok Indah Timur'],
    active: true
  },
  {
    id: 'area-2',
    name: 'Jakarta Barat',
    clusters: ['Permata Hijau 2', 'Citra Garden 3', 'Kebon Jeruk Indah', 'Puri Indah Blok A'],
    active: true
  },
  {
    id: 'area-3',
    name: 'Tangerang Selatan',
    clusters: ['Victoria Riverside', 'Bintaro Jaya Sektor 7', 'BSD Nusa Loka', 'Serpong Park'],
    active: true
  },
  {
    id: 'area-4',
    name: 'Jakarta Utara',
    clusters: ['Sunter Indah', 'Kelapa Gading Permai', 'Pluit Kencana'],
    active: true
  },
  {
    id: 'area-5',
    name: 'Depok',
    clusters: ['Margonda Residence', 'Pesona Khayangan', 'Cinere Delta'],
    active: true
  },
  {
    id: 'area-6',
    name: 'Jakarta Timur',
    clusters: ['Rawamangun Garden', 'Pulomas Residence', 'Cibubur Indah'],
    active: true
  },
  {
    id: 'area-7',
    name: 'Bekasi',
    clusters: ['Harapan Indah Blok A', 'Grand Galaxy City', 'Kemang Pratama'],
    active: true
  }
];

export const DEFAULT_ROOT_CAUSE_CATEGORIES: RootCauseCategory[] = [
  {
    id: 'rc-1',
    name: 'Gangguan Fiber Optic dan Jaringan',
    description: 'Kendala pada media transmisi optik, kabel dropcore, redaman, dan pasif optik (FAT/FDT/ODP)',
    items: [
      'Fiber Optic Putus',
      'Kabel Dropcore Rusak',
      'Kabel Dropcore Tertekuk',
      'Redaman Fiber Tinggi',
      'Konektor Fiber Kotor atau Rusak',
      'Splicing Bermasalah',
      'ODP/FAT Bermasalah',
      'FDT Bermasalah',
      'OLT/Port Bermasalah',
      'Jalur Fiber Tidak Tersedia',
      'Gangguan Jaringan Area',
      'Gangguan Backbone atau Distribusi'
    ]
  },
  {
    id: 'rc-2',
    name: 'ONT, Router, dan Wi-Fi',
    description: 'Kendala pada perangkat aktif pelanggan, konfigurasi, sinyal radio Wi-Fi, dan power',
    items: [
      'ONT Rusak',
      'Router Rusak',
      'ONT Tidak Mendapatkan Daya',
      'ONT LOS',
      'ONT Tidak Terhubung ke Jaringan',
      'Router Tidak Menyala',
      'Wi-Fi Tidak Terdeteksi',
      'Wi-Fi Lemah',
      'Interferensi Wi-Fi',
      'Salah Konfigurasi Router',
      'Masalah DHCP atau IP',
      'Perangkat Pelanggan Bermasalah'
    ]
  },
  {
    id: 'rc-3',
    name: 'Instalasi dan Infrastruktur',
    description: 'Kebutuhan pekerjaan fisik tarikan baru, relokasi, tiang, dan ketersediaan port',
    items: [
      'Instalasi Baru',
      'Relokasi Kabel',
      'Penataan Ulang Kabel',
      'Jalur Kabel Terhalang',
      'Kabel Tidak Cukup',
      'Akses Tiang atau Jalur Terkendala',
      'FAT/ODP Tidak Ditemukan',
      'Port Tidak Tersedia',
      'Perangkat Tidak Sesuai',
      'Instalasi Belum Selesai'
    ]
  },
  {
    id: 'rc-4',
    name: 'Pelanggan dan Lokasi',
    description: 'Kendala non-teknis terkait kehadiran pelanggan, akses hunian, dan jadwal',
    items: [
      'Pelanggan Tidak di Tempat',
      'Pelanggan Tidak Dapat Dihubungi',
      'Pelanggan Menolak Pengerjaan',
      'Alamat Tidak Sesuai',
      'Lokasi Tidak Ditemukan',
      'Akses Rumah atau Gedung Terkendala',
      'Perlu Penjadwalan Ulang',
      'Menunggu Persetujuan Pelanggan'
    ]
  },
  {
    id: 'rc-5',
    name: 'Sistem, Administrasi, dan Operasional',
    description: 'Kesalahan data perintah kerja, penugasan personel, atau ketergantungan material/eskalasi',
    items: [
      'Data WO Tidak Sesuai',
      'Duplikasi WO',
      'Salah Assign Teknisi',
      'Salah Data Perangkat',
      'Menunggu Tim Lain',
      'Menunggu Material',
      'Menunggu Eskalasi',
      'Gangguan Sistem',
      'Kendala Operasional Lainnya'
    ]
  }
];

export const DEFAULT_WORK_RESULTS: string[] = [
  'Berhasil Diperbaiki',
  'Berhasil dengan Penggantian Perangkat',
  'Berhasil dengan Perbaikan Kabel',
  'Berhasil setelah Konfigurasi Ulang',
  'Tidak Berhasil',
  'Pekerjaan Tertunda',
  'Perlu Eskalasi',
  'Perlu Kunjungan Ulang'
];

