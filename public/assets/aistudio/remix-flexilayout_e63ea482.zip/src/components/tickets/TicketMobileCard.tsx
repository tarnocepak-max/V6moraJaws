import React from 'react';
import { Ticket } from '../../types/index.ts';
import { useUIConfig } from '../../context/UIConfigContext';
import { useApp } from '../../context/AppContext';
import { StatusAgentBadge, StatusInstallerBadge, StatusWhatsAppBadge } from '../common/Badge';
import {
  MessageSquare,
  MessageCircle,
  Eye,
  Phone,
  Clock,
  MapPin,
  User,
  Wrench,
  CheckSquare,
  Square,
  Calendar,
  Layers
} from 'lucide-react';

interface TicketMobileCardProps {
  ticket: Ticket;
  isSelected: boolean;
  onToggleSelect: (id: string) => void;
  onSelectTicket: (ticket: Ticket, defaultTab?: 'overview' | 'report' | 'chat' | 'history') => void;
  onOpenWhatsApp: (ticket: Ticket) => void;
}

export const TicketMobileCard: React.FC<TicketMobileCardProps> = ({
  ticket,
  isSelected,
  onToggleSelect,
  onSelectTicket,
  onOpenWhatsApp
}) => {
  const { config } = useUIConfig();
  const { currentUser, getTicketUnreadCount } = useApp();
  const androidConfig = config.device?.android || {
    touchTargetSize: 'comfortable',
    cardDensity: 'comfortable',
    showQuickCall: true,
    showQuickWhatsApp: true,
    showQuickDetail: true,
    highContrastBadges: true
  };

  const isComfortableTouch = androidConfig.touchTargetSize !== 'compact';
  const densityPadding =
    androidConfig.cardDensity === 'spacious'
      ? 'p-4 gap-3'
      : androidConfig.cardDensity === 'compact'
      ? 'p-2.5 gap-2'
      : 'p-3.5 gap-2.5';

  return (
    <div
      className={`rounded-xl border transition-all duration-150 flex flex-col bg-white dark:bg-slate-900 shadow-xs relative overflow-hidden ${
        isSelected
          ? 'border-indigo-500 ring-2 ring-indigo-500/20 bg-indigo-50/20 dark:bg-indigo-950/20'
          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
      } ${densityPadding}`}
    >
      {/* Top Bar: Checkbox + WO Number + Slot Time Badge */}
      <div className="flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            onClick={() => onToggleSelect(ticket.id)}
            className="p-1 -m-1 text-slate-400 hover:text-indigo-600 focus:outline-none min-w-[36px] min-h-[36px] flex items-center justify-center shrink-0"
            aria-label="Select ticket"
          >
            {isSelected ? (
              <CheckSquare className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            ) : (
              <Square className="w-5 h-5" />
            )}
          </button>

          <button
            onClick={() => onSelectTicket(ticket)}
            className="text-left font-mono font-bold text-sm text-indigo-600 dark:text-indigo-400 hover:underline truncate"
            title="Buka Detail Tiket"
          >
            {ticket.woNumber}
          </button>
        </div>

        {/* Slot Time & Category */}
        <div className="flex items-center gap-1.5 shrink-0">
          {ticket.slotTime && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-900/50 text-[11px] font-semibold">
              <Clock className="w-3 h-3" />
              <span>{ticket.slotTime}</span>
            </span>
          )}
          {ticket.ticketCategory && (
            <span className="px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-medium uppercase">
              {ticket.ticketCategory}
            </span>
          )}
        </div>
      </div>

      {/* Customer & Location Details */}
      <div className="flex flex-col gap-1.5 text-xs">
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-white text-sm">
              <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="truncate">{ticket.customerName}</span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate ml-5">
              ID Pelanggan: <span className="font-mono">{ticket.idCustomer}</span>
            </p>
          </div>

          {ticket.area && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-[11px] shrink-0 font-medium">
              <MapPin className="w-3 h-3 text-indigo-500" />
              <span>{ticket.area}</span>
            </div>
          )}
        </div>

        {/* Address summary */}
        {(ticket.streetName || ticket.clusterName) && (
          <div className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400 text-[11.5px] bg-slate-50 dark:bg-slate-800/40 p-1.5 rounded">
            <span className="text-slate-400 font-semibold shrink-0">Alamat:</span>
            <span className="truncate">{ticket.clusterName ? `[${ticket.clusterName}] ` : ''}{ticket.streetName || '-'}</span>
          </div>
        )}

        {/* Assigned Installer Info */}
        <div className="flex items-center justify-between text-xs pt-1">
          <div className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
            <Wrench className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-[11px] text-slate-500">Teknisi:</span>
            {ticket.installerName ? (
              <span className="font-semibold text-slate-900 dark:text-white">{ticket.installerName}</span>
            ) : (
              <span className="text-amber-600 dark:text-amber-400 font-semibold italic text-[11px]">
                Belum Ditugaskan
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-[11px] text-slate-400">
            <Calendar className="w-3 h-3" />
            <span>{ticket.date}</span>
          </div>
        </div>

        {/* Status Badges Group */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <StatusWhatsAppBadge status={ticket.statusWhatsApp} />
          <StatusInstallerBadge status={ticket.statusWOInstaller} />
          <StatusAgentBadge status={ticket.statusWOAgent} />
        </div>
      </div>

      {/* Bottom Action Dock for Mobile Card (Touch-Ergonomic Buttons) */}
      <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 mt-1">
        {/* Chat Action with Unread Badge (Super Admin, Dispatch, Installer only) */}
        {['super_admin', 'dispatch', 'installer'].includes(currentUser.role) && (() => {
          const unread = getTicketUnreadCount(ticket.id);
          return (
            <button
              onClick={() => onSelectTicket(ticket, 'chat')}
              className={`relative flex items-center justify-center gap-1.5 px-3 rounded-lg font-semibold border transition-colors shadow-xs ${
                unread > 0
                  ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-900/60'
                  : 'bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800'
              } ${isComfortableTouch ? 'py-2.5 text-xs min-h-[44px]' : 'py-1.5 text-[11px]'}`}
              title={unread > 0 ? `${unread} Chat Belum Dibaca` : 'Buka Live Chat'}
            >
              <MessageCircle className="w-4 h-4 shrink-0 text-indigo-600 dark:text-indigo-400" />
              <span>Chat</span>
              {unread > 0 && (
                <span className="px-1.5 py-0.2 bg-rose-600 text-white text-[10px] font-bold rounded-full">
                  {unread}
                </span>
              )}
            </button>
          );
        })()}

        {/* WhatsApp Direct Action */}
        {androidConfig.showQuickWhatsApp && (
          <button
            onClick={() => onOpenWhatsApp(ticket)}
            className={`flex-1 flex items-center justify-center gap-1.5 rounded-lg font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 transition-colors shadow-xs ${
              isComfortableTouch ? 'py-2.5 text-xs min-h-[44px]' : 'py-1.5 text-[11px]'
            }`}
            title="Buka Konfirmasi WhatsApp"
          >
            <MessageSquare className="w-4 h-4 shrink-0" />
            <span>WhatsApp URL</span>
          </button>
        )}

        {/* Call Customer Direct Action (Phone Call) */}
        {androidConfig.showQuickCall && ticket.customerPhone && (
          <a
            href={`tel:${ticket.customerPhone}`}
            className={`flex items-center justify-center px-3 rounded-lg text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:bg-slate-300 transition-colors border border-slate-200 dark:border-slate-700 ${
              isComfortableTouch ? 'py-2.5 min-h-[44px]' : 'py-1.5'
            }`}
            title={`Telepon ${ticket.customerPhone}`}
          >
            <Phone className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </a>
        )}

        {/* View / Edit Detail Action */}
        {androidConfig.showQuickDetail && (
          <button
            onClick={() => onSelectTicket(ticket, 'overview')}
            className={`flex-1 flex items-center justify-center gap-1.5 rounded-lg font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 active:bg-slate-300 transition-colors border border-slate-200 dark:border-slate-700 ${
              isComfortableTouch ? 'py-2.5 text-xs min-h-[44px]' : 'py-1.5 text-[11px]'
            }`}
            title="Lihat Detail & Penugasan"
          >
            <Eye className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <span>Detail WO</span>
          </button>
        )}
      </div>
    </div>
  );
};
