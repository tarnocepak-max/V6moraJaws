import React from 'react';
import { useApp } from '../../context/AppContext';
import { useUIConfig } from '../../context/UIConfigContext';
import {
  LayoutDashboard,
  FileSpreadsheet,
  Ticket as TicketIcon,
  Users2,
  Wrench,
  MessageSquareQuote,
  GitBranch,
  Sliders,
  History,
  Settings as SettingsIcon,
  ChevronLeft,
  ChevronRight,
  Minus,
  X,
  Maximize2,
  Users,
  RefreshCw,
  Database,
  Server,
  LogOut
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  sidebarState: 'expanded' | 'minimized' | 'closed';
  onChangeState: (state: 'expanded' | 'minimized' | 'closed') => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onNavigate,
  sidebarState,
  onChangeState
}) => {
  const { currentUser, tickets, googleSheetsConfig } = useApp();
  const { isMobileView, config, navigationItems, menuCategories } = useUIConfig();

  if (sidebarState === 'closed') {
    return null;
  }

  const isMinimized = sidebarState === 'minimized';
  const totalActiveTickets = tickets.filter(t => !t.isArchived).length;
  const unassignedCount = tickets.filter(t => !t.installerName && !t.isArchived).length;

  // Base catalog of navigation metadata
  const itemCatalog: Record<
    string,
    {
      label: string;
      icon: any;
      roles: string[];
      highlight?: boolean;
      badge?: string | number;
      badgeColor?: string;
    }
  > = {
    dashboard: {
      label: 'Dashboard Monitoring',
      icon: LayoutDashboard,
      roles: ['super_admin', 'dispatch', 'leader', 'installer']
    },
    tickets: {
      label: 'Ticket Information',
      icon: TicketIcon,
      badge: totalActiveTickets,
      roles: ['super_admin', 'dispatch', 'leader', 'installer']
    },
    import: {
      label: 'Import',
      icon: FileSpreadsheet,
      roles: ['super_admin', 'dispatch']
    },
    sheets_sync: {
      label: 'Google Sheet Sync',
      icon: RefreshCw,
      badge: googleSheetsConfig.enabled ? 'Auto' : undefined,
      badgeColor: 'emerald',
      roles: ['super_admin']
    },
    leader_portal: {
      label: 'Leader / Korlap Portal',
      icon: Users2,
      badge: unassignedCount > 0 ? `${unassignedCount} unassigned` : undefined,
      badgeColor: 'amber',
      roles: ['super_admin', 'dispatch', 'leader']
    },
    installer_portal: {
      label: 'Installer / Teknisi Portal',
      icon: Wrench,
      roles: ['super_admin', 'leader', 'installer']
    },
    templates: {
      label: 'WhatsApp Templates',
      icon: MessageSquareQuote,
      roles: ['super_admin', 'dispatch', 'leader']
    },
    workflows: {
      label: 'Workflow Automation',
      icon: GitBranch,
      roles: ['super_admin', 'dispatch']
    },
    ui_builder: {
      label: 'UI Configuration Builder',
      icon: Sliders,
      highlight: true,
      roles: ['super_admin', 'dispatch']
    },
    audit_logs: {
      label: 'Audit Log & History',
      icon: History,
      roles: ['super_admin']
    },
    users: {
      label: 'Manajemen Akun (RBAC)',
      icon: Users,
      roles: ['super_admin']
    },
    settings: {
      label: 'Master Data & Settings',
      icon: SettingsIcon,
      roles: ['super_admin']
    },
    database_management: {
      label: 'Database Management',
      icon: Server,
      roles: ['super_admin']
    },
    offline_sync: {
      label: 'Sinkronisasi Offline',
      icon: Database,
      roles: ['super_admin', 'dispatch', 'leader', 'installer']
    }
  };

  // Merge dynamic navigationItems with itemCatalog and filter by user role and visibility
  const sortedNavItems = [...navigationItems].sort((a, b) => a.order - b.order);

  // Group items by category
  const categoriesToRender = (menuCategories && menuCategories.length > 0)
    ? menuCategories
    : ['Utama & Monitoring', 'Operasional & Integrasi', 'Portal Lapangan', 'Automasi & Kustomisasi', 'Pengaturan & Sistem'];

  const handleItemClick = (id: string) => {
    onNavigate(id);
    if (isMobileView || (typeof window !== 'undefined' && window.innerWidth < 768)) {
      if (config.device?.android?.autoCloseSidebarOnNavigate !== false) {
        onChangeState('closed');
      }
    }
  };

  return (
    <>
      {/* Mobile Backdrop when open on mobile */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-45 md:hidden"
        onClick={() => onChangeState('closed')}
      />

      <aside
        className={`fixed inset-y-0 left-0 z-50 md:relative md:inset-auto md:z-auto bg-slate-50 dark:bg-slate-900/95 border-r border-slate-200 dark:border-slate-800 transition-all duration-200 flex flex-col shrink-0 shadow-2xl md:shadow-none h-full ${
          isMinimized ? 'w-16' : 'w-64'
        }`}
      >
      {/* Top Header of Sidebar: Menu title with Minimize (-) and Close (X) buttons */}
      <div className="px-3 py-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
        {!isMinimized ? (
          <>
            <span className="font-semibold text-slate-500 uppercase tracking-wider text-[11px]">
              Menu Navigasi
            </span>
            <div className="flex items-center gap-1">
              {/* Minimize Button */}
              <button
                onClick={() => onChangeState('minimized')}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded transition-colors"
                title="Minimize Menu (Kecilkan ke Ikon)"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              {/* Close Button */}
              <button
                onClick={() => onChangeState('closed')}
                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
                title="Tutup Menu (Sembunyikan Penuh)"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </>
        ) : (
          <div className="w-full flex items-center justify-center gap-1">
            {/* Expand Button */}
            <button
              onClick={() => onChangeState('expanded')}
              className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-200/60 dark:hover:bg-slate-800 rounded transition-colors"
              title="Perbesar Menu (Expand)"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            {/* Close Button */}
            <button
              onClick={() => onChangeState('closed')}
              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded transition-colors"
              title="Tutup Menu"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Navigation items list grouped by category */}
      <div className="flex-1 py-2 px-2 space-y-3 overflow-y-auto">
        {categoriesToRender.map(category => {
          const categoryItems = sortedNavItems.filter(item => {
            const catalog = itemCatalog[item.id];
            if (!catalog) return false;
            if (!item.visible) return false;
            if (!catalog.roles.includes(currentUser.role)) return false;
            return item.category === category;
          });

          if (categoryItems.length === 0) return null;

          return (
            <div key={category} className="space-y-1">
              {!isMinimized ? (
                <div className="px-3 pt-1.5 pb-0.5 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  {category}
                </div>
              ) : (
                <div className="my-1 border-t border-slate-200 dark:border-slate-800/80" />
              )}

              {categoryItems.map(item => {
                const catalog = itemCatalog[item.id] || { label: item.label, icon: TicketIcon, roles: [] };
                const Icon = catalog.icon;
                const isActive = activeTab === item.id;
                const label = item.label || catalog.label;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item.id)}
                    title={isMinimized ? label : undefined}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-all ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : catalog.highlight
                        ? 'text-indigo-700 dark:text-indigo-300 bg-indigo-50/70 dark:bg-indigo-950/40 hover:bg-indigo-100 dark:hover:bg-indigo-900/40'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    {!isMinimized && (
                      <div className="flex-1 flex items-center justify-between text-left truncate">
                        <span className="truncate">{label}</span>
                        {catalog.badge !== undefined && (
                          <span
                            className={`ml-2 px-1.5 py-0.2 text-[10px] font-semibold rounded ${
                              isActive
                                ? 'bg-indigo-700 text-white'
                                : catalog.badgeColor === 'amber'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {catalog.badge}
                          </span>
                        )}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Footer controls */}
      <div className="p-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
        {!isMinimized && (
          <div className="px-2 text-[11px] text-slate-400 truncate">
            Role: <span className="font-semibold text-slate-700 dark:text-slate-300 capitalize">{currentUser.role.replace('_', ' ')}</span>
          </div>
        )}
        <div className="flex items-center gap-1 ml-auto">
          {/* Quick toggle between minimized & expanded */}
          <button
            onClick={() => onChangeState(isMinimized ? 'expanded' : 'minimized')}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors"
            title={isMinimized ? 'Expand Menu' : 'Minimize Menu'}
          >
            {isMinimized ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </aside>
    </>
  );
};
