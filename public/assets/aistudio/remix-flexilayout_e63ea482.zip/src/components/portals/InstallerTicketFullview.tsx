import React, { useState } from 'react';
import { Ticket, TicketStatusWOInstaller, TechnicalReport } from '../../types/index.ts';
import { useApp } from '../../context/AppContext';
import { StatusInstallerBadge, StatusWhatsAppBadge, StatusAgentBadge } from '../common/Badge';
import { buildWhatsAppClickToChatUrl } from '../../services/whatsappService';
import {
  ArrowLeft,
  Phone,
  MessageSquare,
  MapPin,
  CheckCircle2,
  Navigation,
  Clock,
  Calendar,
  Building2,
  User,
  Wrench,
  Radio,
  Wifi,
  Copy,
  Check,
  AlertTriangle,
  Send,
  Save,
  Camera,
  ExternalLink,
  Layers,
  Sparkles,
  HelpCircle,
  FileText
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface InstallerTicketFullviewProps {
  ticket: Ticket;
  onBack: () => void;
  onOpenWhatsApp: (ticket: Ticket) => void;
}

export const InstallerTicketFullview: React.FC<InstallerTicketFullviewProps> = ({
  ticket,
  onBack,
  onOpenWhatsApp
}) => {
  const {
    updateTicketStatus,
    saveTechnicalReport,
    rootCauseCategories,
    workResultsList,
    templates,
    currentUser
  } = useApp();
  const { toast } = useToast();

  const [copiedAddress, setCopiedAddress] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'report'>('details');

  // Technical report state
  const existingReport = ticket.technicalReport;
  const [opticalPowerDbm, setOpticalPowerDbm] = useState(existingReport?.opticalPowerDbm || '-19.2');
  const [mainCategory, setMainCategory] = useState(existingReport?.mainCategory || (rootCauseCategories[0]?.name || 'Wi-Fi / Fiber Optic'));
  const [rootCause, setRootCause] = useState(existingReport?.rootCause || 'Konektor FO Redaman Tinggi');
  const [workResult, setWorkResult] = useState(existingReport?.workResult || (workResultsList[0] || 'Instalasi Selesai Sesuai Standar'));
  const [technicalDescription, setTechnicalDescription] = useState(existingReport?.technicalDescription || '');
  const [correctiveAction, setCorrectiveAction] = useState(existingReport?.correctiveAction || '');
  const [usedMaterials, setUsedMaterials] = useState(existingReport?.usedMaterials || 'Dropcore 150m, 1 Roset, 2 Fast Connector');
  const [deviceSerialNumber, setDeviceSerialNumber] = useState(existingReport?.deviceSerialNumber || ticket.ontSerialNumber || '');
  const [photoPreview, setPhotoPreview] = useState<string | null>(existingReport?.photoAfterUrl || null);

  // Quick WhatsApp link beside customer phone
  const waUrlObj = buildWhatsAppClickToChatUrl(
    ticket.customerPhone,
    `Halo ${ticket.customerName}, saya teknisi ${currentUser.name || 'MoraJaws'} terkait pemasangan WO ${ticket.woNumber} hari ini.`
  );

  const handleCopyAddress = () => {
    const fullAddr = `${ticket.streetName || ticket.address || ''}, ${ticket.clusterName || ''}, ${ticket.area || ''}`.trim();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(fullAddr);
      setCopiedAddress(true);
      toast.success('Alamat lengkap berhasil disalin ke clipboard.', 'Disalin');
      setTimeout(() => setCopiedAddress(false), 2000);
    }
  };

  const handleOpenMaps = () => {
    const query = encodeURIComponent(`${ticket.streetName || ticket.address || ''} ${ticket.clusterName || ''} ${ticket.area || ''}`);
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
        toast.info('Foto dokumentasi pengerjaan berhasil dimuat.', 'Foto Dipilih');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleQuickStatusChange = (newStatus: TicketStatusWOInstaller) => {
    updateTicketStatus(ticket.id, undefined, newStatus, `Status diperbarui oleh teknisi ${currentUser.name}: ${newStatus}`);
    toast.success(`Status tiket diubah menjadi: ${newStatus}`, 'Status Diperbarui');
  };

  const handleSaveReport = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = saveTechnicalReport(ticket.id, {
      mainCategory,
      rootCause,
      workResult,
      technicalDescription: technicalDescription || `Pengerjaan tiket ${ticket.woNumber} oleh ${currentUser.name}`,
      correctiveAction: correctiveAction || 'Penyambungan ulang fast connector dan pengujian redaman OPM',
      opticalPowerDbm,
      usedMaterials,
      deviceSerialNumber,
      photoAfterUrl: photoPreview || undefined
    });

    if (res.success) {
      toast.success('Laporan teknis berhasil disimpan dan dicatat ke sistem.', 'Laporan Tersimpan');
    } else {
      toast.error(res.error || 'Gagal menyimpan laporan teknis.', 'Kesalahan');
    }
  };

  const handleMarkCompleted = () => {
    handleSaveReport();
    updateTicketStatus(ticket.id, 'Resolved', 'Completed', `Pekerjaan telah rampung dan diselesaikan oleh ${currentUser.name}. OPM: ${opticalPowerDbm} dBm`);
    toast.success(`Tiket ${ticket.woNumber} berhasil diselesaikan.`, 'Pekerjaan Rampung');
  };

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen -m-3 sm:-m-6 lg:-m-8 flex flex-col">
      {/* Top Sticky Header */}
      <div className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="p-2 -ml-1 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5 text-xs font-bold shrink-0"
            title="Kembali ke Daftar WO"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Kembali</span>
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono font-extrabold text-sm sm:text-base text-slate-900 dark:text-white">
                {ticket.woNumber}
              </span>
              <StatusInstallerBadge status={ticket.statusWOInstaller} />
              <StatusAgentBadge status={ticket.statusWOAgent} />
            </div>
            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
              Jadwal Appointment: <strong className="text-slate-700 dark:text-slate-300">{ticket.appointmentDate || ticket.date}</strong> · Slot: <strong className="text-indigo-600 dark:text-indigo-400">{ticket.slotTime}</strong>
            </div>
          </div>
        </div>

        {/* Header Quick Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setActiveTab(activeTab === 'details' ? 'report' : 'details')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 border ${
              activeTab === 'report'
                ? 'bg-indigo-600 text-white border-indigo-600'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>{activeTab === 'report' ? 'Lihat Info WO' : 'Form Laporan'}</span>
          </button>
        </div>
      </div>

      {/* Main Content Viewport */}
      <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full pb-28 space-y-6">
        {/* Section A: Customer & Location Cards (Prominent Border Discipline) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Box 1: Informasi Pelanggan dengan Tombol WhatsApp tepat di sebelah Telepon */}
          <div className="p-5 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                <User className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Informasi Pelanggan</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-md">
                ID: {ticket.idCustomer || ticket.customerId || '-'}
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div>
                <div className="text-[11px] text-slate-400">Nama Pelanggan</div>
                <div className="font-bold text-sm text-slate-900 dark:text-white">
                  {ticket.customerName || ticket.endUserName || '-'}
                </div>
              </div>

              {/* Exact user requirement: Customer Phone [Tombol WhatsApp] */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80">
                <div className="text-[11px] text-slate-400 mb-1">Nomor Telepon & WhatsApp Pelanggan</div>
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                      {ticket.customerPhone || 'Tidak ada nomor'}
                    </span>
                  </div>

                  {ticket.customerPhone ? (
                    <div className="flex items-center gap-1.5">
                      <a
                        href={`tel:${ticket.customerPhone}`}
                        className="p-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1"
                        title="Telepon Langsung"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Panggil</span>
                      </a>
                      <button
                        onClick={() => {
                          if (waUrlObj.url) {
                            window.open(waUrlObj.url, '_blank');
                          } else {
                            onOpenWhatsApp(ticket);
                          }
                        }}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
                        title="Chat WhatsApp Pelanggan"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat WhatsApp</span>
                      </button>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 italic">Nomor belum terisi</span>
                  )}
                </div>

                {ticket.customerContact2 && (
                  <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Kontak Cadangan:</span>
                    <span className="font-mono font-medium text-slate-700 dark:text-slate-300">{ticket.customerContact2}</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Box 2: Informasi Lokasi & Navigasi */}
          <div className="p-5 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm space-y-3.5">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                <MapPin className="w-4 h-4 text-rose-600 dark:text-rose-400" />
                <span>Informasi Lokasi & Alamat</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                Area: {ticket.area || '-'}
              </span>
            </div>

            <div className="space-y-2.5 text-xs">
              <div>
                <div className="text-[11px] text-slate-400">Cluster / Komplek</div>
                <div className="font-bold text-slate-900 dark:text-white">
                  {ticket.clusterName || 'Non-Cluster'}
                </div>
              </div>

              <div>
                <div className="text-[11px] text-slate-400">Alamat Lengkap & Jalan</div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 leading-relaxed font-medium">
                  {ticket.streetName || ticket.address || 'Alamat belum diinput'}
                  {ticket.streetAlternatif && (
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 italic border-t border-slate-200/60 dark:border-slate-700/40 pt-1">
                      Patokan: {ticket.streetAlternatif}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Navigasi & Salin */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={handleCopyAddress}
                  className="flex-1 py-2 px-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors"
                >
                  {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedAddress ? 'Tersalin' : 'Salin Alamat'}</span>
                </button>
                <button
                  onClick={handleOpenMaps}
                  className="flex-1 py-2 px-3 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors border border-indigo-200 dark:border-indigo-800"
                >
                  <Navigation className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  <span>Google Maps</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Section B: Detail Teknis & Infrastruktur Jaringan */}
        <div className="p-5 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              <Radio className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Infrastruktur Jaringan & Detail Pekerjaan</span>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 font-semibold">
              {ticket.ticketCategory || 'FTTH Service'}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
              <div className="text-[10.5px] text-slate-400">Kode FDT</div>
              <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                {ticket.fdtCode || '-'}
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
              <div className="text-[10.5px] text-slate-400">Kode FAT & Port</div>
              <div className="font-mono font-bold text-slate-800 dark:text-slate-200 mt-0.5">
                {ticket.fatCode || '-'}{ticket.fatPort ? ` (Port ${ticket.fatPort})` : ''}
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
              <div className="text-[10.5px] text-slate-400">Vendor Kontraktor</div>
              <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5 truncate">
                {ticket.contactorName || ticket.contractorName || '-'}
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
              <div className="text-[10.5px] text-slate-400">Leader / Korlap</div>
              <div className="font-bold text-slate-800 dark:text-slate-200 mt-0.5 truncate">
                {ticket.leaderName || ticket.corlapName || '-'}
              </div>
            </div>
          </div>
        </div>

        {/* Section C: Form Laporan Teknis Teknisi */}
        <div className="p-5 sm:p-6 rounded-2xl border-2 border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Wrench className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h3 className="font-bold text-sm sm:text-base text-slate-900 dark:text-white">
                Laporan Teknis Lapangan (Technical Report)
              </h3>
            </div>
            <span className="text-xs text-slate-500">
              Wajib diisi sebelum dinyatakan Selesai
            </span>
          </div>

          <form onSubmit={handleSaveReport} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Pengukuran Redaman OPM (dBm) *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={opticalPowerDbm}
                    onChange={e => setOpticalPowerDbm(e.target.value)}
                    placeholder="misal: -18.5"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono font-bold text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                  <div className="absolute inset-y-0 right-3 flex items-center text-slate-400 font-bold">
                    dBm
                  </div>
                </div>
                <div className="text-[10.5px] text-slate-400 mt-1">Standar ideal instalasi: -16.0 dBm s/d -24.0 dBm</div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nomor Seri Perangkat (ONT / Router SN)
                </label>
                <input
                  type="text"
                  value={deviceSerialNumber}
                  onChange={e => setDeviceSerialNumber(e.target.value)}
                  placeholder="SN: HWTC12345678"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Kategori Masalah / Pekerjaan
                </label>
                <select
                  value={mainCategory}
                  onChange={e => setMainCategory(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
                >
                  {rootCauseCategories.map(c => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hasil Pekerjaan (Work Result)
                </label>
                <select
                  value={workResult}
                  onChange={e => setWorkResult(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-medium"
                >
                  {workResultsList.map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Material yang Digunakan
              </label>
              <input
                type="text"
                value={usedMaterials}
                onChange={e => setUsedMaterials(e.target.value)}
                placeholder="misal: Dropcore 120m, 1 Roset, 2 Fast Connector"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Catatan Teknis & Penjelasan Lapangan
              </label>
              <textarea
                rows={3}
                value={technicalDescription}
                onChange={e => setTechnicalDescription(e.target.value)}
                placeholder="Rincian proses pekerjaan, kendala di lapangan, atau pesan kepada Dispatch..."
                className="w-full px-3 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white resize-none"
              />
            </div>

            {/* Photo Attachment Picker */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                Dokumentasi Foto Pengerjaan / Bukti ONT Menyala
              </label>
              <div className="flex items-center gap-3">
                <label className="px-3 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl font-bold cursor-pointer flex items-center gap-2 border border-slate-200 dark:border-slate-700">
                  <Camera className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>Ambil / Pilih Foto</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
                {photoPreview && (
                  <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Foto terlampir
                  </span>
                )}
              </div>
              {photoPreview && (
                <div className="mt-2.5 relative inline-block rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-sm">
                  <img src={photoPreview} alt="Bukti Pengerjaan" className="w-32 h-24 object-cover" />
                  <button
                    type="button"
                    onClick={() => setPhotoPreview(null)}
                    className="absolute top-1 right-1 p-1 bg-black/60 text-white rounded-full text-[10px]"
                    title="Hapus Foto"
                  >
                    &times;
                  </button>
                </div>
              )}
            </div>

            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="submit"
                className="px-4 py-2 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Simpan Draft Laporan</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Sticky Bottom Actions Bar (Ergonomic for Android Smartphone Thumb Navigation) */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 p-3 sm:px-8 shadow-xl flex items-center justify-between gap-2 max-w-5xl mx-auto">
        <div className="flex items-center gap-1.5 overflow-x-auto py-1">
          <button
            onClick={() => handleQuickStatusChange('En Route')}
            className="px-3 py-2 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 text-blue-700 dark:text-blue-300 font-bold text-xs rounded-xl border border-blue-200 dark:border-blue-800 shrink-0 flex items-center gap-1.5"
          >
            <span>Otw Lokasi (En Route)</span>
          </button>
          <button
            onClick={() => handleQuickStatusChange('On Site')}
            className="px-3 py-2 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-xs rounded-xl border border-indigo-200 dark:border-indigo-800 shrink-0 flex items-center gap-1.5"
          >
            <span>Tiba di Lokasi (On Site)</span>
          </button>
          <button
            onClick={() => handleQuickStatusChange('Pending Technical')}
            className="px-3 py-2 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 text-amber-700 dark:text-amber-300 font-bold text-xs rounded-xl border border-amber-200 dark:border-amber-800 shrink-0 flex items-center gap-1.5"
          >
            <span>Reschedule / Kendala</span>
          </button>
        </div>

        <div className="shrink-0 flex items-center gap-2">
          <button
            onClick={handleMarkCompleted}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/30 flex items-center gap-1.5 transition-all hover:scale-105"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Tandai Selesai</span>
          </button>
        </div>
      </div>
    </div>
  );
};
