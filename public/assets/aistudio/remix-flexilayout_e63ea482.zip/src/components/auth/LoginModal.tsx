import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import {
  ShieldCheck,
  Shield,
  Building2,
  Wrench,
  Lock,
  User,
  ArrowRight,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  X,
  Sparkles,
  KeyRound
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose?: () => void;
  onLoginSuccess?: (role: UserRole) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess
}) => {
  const { login, currentUser, logout } = useApp();

  const [username, setUsername] = useState('superadmin');
  const [password, setPassword] = useState('12345678');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [activePresetCategory, setActivePresetCategory] = useState<UserRole>('super_admin');

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    setTimeout(() => {
      const res = login(username.trim(), password);
      setLoading(false);

      if (res.success && res.user) {
        onLoginSuccess?.(res.user.role);
        onClose?.();
      } else {
        setError(res.error || 'Kombinasi nama pengguna atau kata sandi tidak valid.');
      }
    }, 250);
  };

  const selectCategoryPreset = (role: UserRole) => {
    setActivePresetCategory(role);
    setError(null);
    switch (role) {
      case 'super_admin':
        setUsername('superadmin');
        setPassword('12345678');
        break;
      case 'dispatch':
        setUsername('dispatch_rina');
        setPassword('12345678');
        break;
      case 'leader':
        setUsername('leader_hendra');
        setPassword('12345678');
        break;
      case 'installer':
        setUsername('installer_andi');
        setPassword('12345678');
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-70 flex items-center justify-center bg-slate-950/70 p-3 sm:p-4 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center font-bold text-lg text-white shadow-md">
                M
              </div>
              <div>
                <h3 className="font-bold text-base tracking-tight">MoraJaws Security Portal</h3>
                <p className="text-xs text-indigo-200 font-medium">Autentikasi & Otorisasi Berdasarkan Kategori Akun</p>
              </div>
            </div>

            {onClose && (
              <button
                onClick={onClose}
                className="p-1 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* 4 Account Categories Tabs */}
        <div className="p-6 space-y-5 text-xs">
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
              Pilih Kategori Akun untuk Pengujian Cepat:
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => selectCategoryPreset('super_admin')}
                className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  activePresetCategory === 'super_admin'
                    ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/50 text-purple-900 dark:text-purple-200 ring-2 ring-purple-500/30'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <ShieldCheck className="w-5 h-5 text-purple-600" />
                <span className="font-bold text-[11px]">Super Admin</span>
              </button>

              <button
                type="button"
                onClick={() => selectCategoryPreset('dispatch')}
                className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  activePresetCategory === 'dispatch'
                    ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-900 dark:text-indigo-200 ring-2 ring-indigo-500/30'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Shield className="w-5 h-5 text-indigo-600" />
                <span className="font-bold text-[11px]">Dispatch</span>
              </button>

              <button
                type="button"
                onClick={() => selectCategoryPreset('leader')}
                className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  activePresetCategory === 'leader'
                    ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/50 text-amber-900 dark:text-amber-200 ring-2 ring-amber-500/30'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Building2 className="w-5 h-5 text-amber-600" />
                <span className="font-bold text-[11px]">Leader</span>
              </button>

              <button
                type="button"
                onClick={() => selectCategoryPreset('installer')}
                className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  activePresetCategory === 'installer'
                    ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-900 dark:text-emerald-200 ring-2 ring-emerald-500/30'
                    : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                }`}
              >
                <Wrench className="w-5 h-5 text-emerald-600" />
                <span className="font-bold text-[11px]">Installer</span>
              </button>
            </div>
          </div>

          {/* Account Category Details Card */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 text-[11.5px] space-y-1">
            <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
              <span className="capitalize">Kategori: {activePresetCategory.replace('_', ' ')}</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-700 font-mono">
                Pass default: 12345678
              </span>
            </div>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              {activePresetCategory === 'super_admin' && 'Akses penuh seluruh modul, kelola akun, otoritas mutlak hapus data & audit log.'}
              {activePresetCategory === 'dispatch' && 'Monitoring seluruh WO, distribusi WO, import data, live chat, close ticket. (Tidak berhak hapus).'}
              {activePresetCategory === 'leader' && 'Khusus WO kontraktor terikat (PT Mitra Jaringan Solusi), pengaturan jadwal & teknisi.'}
              {activePresetCategory === 'installer' && 'Hanya tiket WO yang ditugaskan ke teknisi (Andi Saputra), laporan teknis & live chat.'}
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Username atau Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="Masukkan username atau email..."
                  className="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Kata Sandi (Password Hashed)
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Masukkan kata sandi..."
                  className="w-full pl-9 pr-10 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-medium text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>{loading ? 'Memvalidasi Kredensial...' : 'Masuk ke Sistem MoraJaws'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/40 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>Sesi Aktif: 8 Jam (Token Berenkripsi)</span>
          <span>Audit Log Login: Tercatat Otomatis</span>
        </div>
      </div>
    </div>
  );
};
