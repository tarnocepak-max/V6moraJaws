import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types/index.ts';
import {
  ShieldCheck,
  Shield,
  Building2,
  Wrench,
  Lock,
  User,
  ArrowRight,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  Server,
  Layers,
  KeyRound,
  Sparkles,
  Info
} from 'lucide-react';

interface StaffLoginPortalProps {
  onLoginSuccess?: (role: UserRole) => void;
}

export const StaffLoginPortal: React.FC<StaffLoginPortalProps> = ({ onLoginSuccess }) => {
  const { login, users } = useApp();
  const [username, setUsername] = useState('superadmin');
  const [password, setPassword] = useState('12345678');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedRolePreset, setSelectedRolePreset] = useState<UserRole>('super_admin');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!username.trim()) {
      setError('Nama pengguna atau alamat email wajib diisi.');
      return;
    }
    if (!password) {
      setError('Kata sandi wajib diisi.');
      return;
    }

    setLoading(true);
    setTimeout(() => {
      const res = login(username.trim(), password);
      setLoading(false);
      if (res.success && res.user) {
        onLoginSuccess?.(res.user.role);
      } else {
        setError(res.error || 'Kredensial login tidak valid. Pastikan akun terdaftar dan aktif.');
      }
    }, 300);
  };

  const selectPresetAccount = (role: UserRole) => {
    setSelectedRolePreset(role);
    setError(null);
    const candidate = users.find(u => u.role === role && u.active && !u.isArchived);
    if (candidate) {
      setUsername(candidate.username);
      setPassword('12345678');
    } else {
      switch (role) {
        case 'super_admin':
          setUsername('superadmin');
          setPassword('12345678');
          break;
        case 'dispatch':
          setUsername('dispatch_rina');
          setPassword('12345678');
          break;
        case 'leader':
          setUsername('leader_hendra');
          setPassword('12345678');
          break;
        case 'installer':
          setUsername('installer_andi');
          setPassword('12345678');
          break;
      }
    }
  };

  const getRoleCardDetails = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return {
          title: 'Super Agent',
          badge: 'Super Admin',
          desc: 'Akses penuh administrasi, impor WO, anti-duplikasi, & Database Management.',
          icon: ShieldCheck,
          color: 'text-purple-600 dark:text-purple-400',
          bg: 'bg-purple-50 dark:bg-purple-950/40 border-purple-200 dark:border-purple-800'
        };
      case 'dispatch':
        return {
          title: 'Dispatch Officer',
          badge: 'Dispatch',
          desc: 'Monitoring distribusi, monitoring teknisi, filter jadwal, & impor WO.',
          icon: Shield,
          color: 'text-indigo-600 dark:text-indigo-400',
          bg: 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800'
        };
      case 'leader':
        return {
          title: 'Leader / Korlap',
          badge: 'Mitra Lapangan',
          desc: 'Monitoring area kontraktor, penugasan WO ke teknisi, & progres harian.',
          icon: Building2,
          color: 'text-amber-600 dark:text-amber-400',
          bg: 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800'
        };
      case 'installer':
        return {
          title: 'Teknisi / Installer',
          badge: 'Installer',
          desc: 'Tampilan Fullview WO yang ditugaskan, jadwal appointment, & laporan teknis.',
          icon: Wrench,
          color: 'text-emerald-600 dark:text-emerald-400',
          bg: 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800'
        };
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden">
      {/* Background visual elements */}
      <div className="absolute inset-0 bg-radial from-indigo-900/30 via-slate-900 to-slate-950 pointer-events-none" />
      <div className="absolute -top-32 -right-32 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-4xl flex flex-col items-center">
        {/* Brand header */}
        <div className="text-center mb-6 sm:mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-300 text-xs font-semibold mb-3">
            <Server className="w-3.5 h-3.5 text-indigo-400" />
            <span>MoraJaws Dispatch Management System</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Portal Autentikasi Staff
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto">
            Masuk dengan akun staff resmi terdaftar untuk mengakses dashboard sesuai peran, kontraktor, dan jadwal penugasan.
          </p>
        </div>

        {/* Main card grid */}
        <div className="w-full bg-white dark:bg-slate-900/95 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl backdrop-blur-md overflow-hidden grid grid-cols-1 lg:grid-cols-12">
          {/* Left panel: Role Quick Selector for Testing */}
          <div className="lg:col-span-5 bg-slate-50 dark:bg-slate-950/60 p-5 sm:p-6 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Pilih Kategori Role Akun:
                </h3>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-4">
                Pilih profil akun yang sudah terdaftar di database untuk memuat kredensial secara cepat:
              </p>

              <div className="space-y-2">
                {(['super_admin', 'dispatch', 'leader', 'installer'] as UserRole[]).map(role => {
                  const details = getRoleCardDetails(role);
                  const Icon = details.icon;
                  const isSelected = selectedRolePreset === role;
                  const registeredCount = users.filter(u => u.role === role && u.active && !u.isArchived).length;

                  return (
                    <button
                      key={role}
                      type="button"
                      onClick={() => selectPresetAccount(role)}
                      className={`w-full text-left p-3 rounded-xl border transition-all flex items-start gap-3 ${
                        isSelected
                          ? `${details.bg} ring-2 ring-indigo-500 shadow-sm`
                          : 'bg-white dark:bg-slate-900/80 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className={`p-2 rounded-lg bg-white dark:bg-slate-800 shadow-xs shrink-0 ${details.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-bold text-xs text-slate-900 dark:text-white">
                            {details.title}
                          </span>
                          <span className="text-[9.5px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                            {registeredCount} Akun
                          </span>
                        </div>
                        <p className="text-[10.5px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">
                          {details.desc}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-500 shrink-0" />
              <span>Password default akun demo internal: <strong className="font-mono text-slate-700 dark:text-slate-300">12345678</strong></span>
            </div>
          </div>

          {/* Right panel: Login form */}
          <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center">
            <div className="mb-5">
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <span>Masuk ke Akun Staff</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Silakan masukkan username dan kata sandi staff yang terdaftar.
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300">
                <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                <div className="flex-1 font-medium">{error}</div>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Username atau Email Staff
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={e => setUsername(e.target.value)}
                    placeholder="misal: superadmin / leader_hendra"
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Kata Sandi
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 disabled:pointer-events-none"
                >
                  {loading ? (
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Masuk ke Dashboard</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

              <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
                <span>Enkripsi Sesi: SHA-256 + Salt</span>
                <span>Audit Log: Aktif</span>
              </div>
            </form>
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-6 text-center text-xs text-slate-500">
          MoraJaws Dispatch Management System &copy; 2026. Seluruh hak cipta dilindungi.
        </div>
      </div>
    </div>
  );
};
