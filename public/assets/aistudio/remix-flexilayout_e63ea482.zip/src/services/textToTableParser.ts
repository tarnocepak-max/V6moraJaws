import {
  HeaderMapping,
  ParsedRowData,
  TextToTableResult,
  Ticket,
  Contractor,
  CoverageArea
} from '../types/index.ts';
import {
  processRawImportWithEngine,
  MASTER_CANONICAL_FIELDS,
  parseExcelWorkbook
} from './woFieldMappingEngine.ts';

export interface ParseOptions {
  customMappings?: HeaderMapping[];
  existingWoNumbers?: string[];
  contractors?: Contractor[];
  coverageAreas?: CoverageArea[];
}

/**
 * Parse uploaded Excel or CSV file buffer
 */
export function parseWorkOrderFile(fileBuffer: ArrayBuffer, options: ParseOptions = {}): TextToTableResult {
  const rawRows = parseExcelWorkbook(fileBuffer);
  const existingWoNumbers = new Set(options.existingWoNumbers || []);

  const engineResult = processRawImportWithEngine(
    rawRows,
    existingWoNumbers,
    options.contractors || [],
    options.coverageAreas || [],
    MASTER_CANONICAL_FIELDS
  );

  return {
    totalDetected: engineResult.parsedRows.length,
    validCount: engineResult.validCount,
    problematicCount: engineResult.problematicCount,
    duplicateCount: engineResult.duplicateCount,
    unrecognizedHeaders: engineResult.unrecognizedHeaders,
    detectedHeaders: engineResult.detectedHeaders,
    parsedRows: engineResult.parsedRows,
    detectedContractors: engineResult.detectedContractors,
    newCoverageAreas: engineResult.newCoverageAreas
  };
}


/**
 * Deterministic text parser supporting Markdown tables, TSV, CSV, and delimiter formats,
 * powered by the central WOFieldMappingEngine.
 */
export function parseWorkOrderText(rawText: string, options: ParseOptions = {}): TextToTableResult {
  const existingWoNumbers = new Set(options.existingWoNumbers || []);

  if (!rawText || !rawText.trim()) {
    return {
      totalDetected: 0,
      validCount: 0,
      problematicCount: 0,
      duplicateCount: 0,
      unrecognizedHeaders: [],
      detectedHeaders: [],
      parsedRows: []
    };
  }

  // Split lines, normalize line endings
  const lines = rawText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

  if (lines.length === 0) {
    return {
      totalDetected: 0,
      validCount: 0,
      problematicCount: 0,
      duplicateCount: 0,
      unrecognizedHeaders: [],
      detectedHeaders: [],
      parsedRows: []
    };
  }

  // Determine delimiter: Markdown Pipe '|', Tab '\t', Semicolon ';', or Comma ','
  const firstLine = lines[0];
  const isMarkdownTable = firstLine.includes('|');
  const delimiter = isMarkdownTable ? '|' : (firstLine.includes('\t') ? '\t' : (firstLine.includes(';') ? ';' : ','));

  // Parse header line
  let rawHeaders: string[] = [];
  let dataLinesStartIndex = 1;

  if (isMarkdownTable) {
    rawHeaders = splitMarkdownRow(firstLine);
    // Check if second line is a Markdown separator line (e.g., |---|:---|---:|)
    if (lines.length > 1 && isMarkdownSeparator(lines[1])) {
      dataLinesStartIndex = 2;
    }
  } else {
    rawHeaders = splitDelimitedRow(firstLine, delimiter);
  }

  // Clean and trim headers, handling blank headers without throwing away
  const detectedHeaders = rawHeaders.map((h, i) => h.trim() || `Unnamed_Column_${i + 1}`);

  const rawRows: Record<string, string>[] = [];

  // Collect raw rows
  for (let i = dataLinesStartIndex; i < lines.length; i++) {
    const line = lines[i];
    if (isMarkdownTable && isMarkdownSeparator(line)) {
      continue; // Skip any extra separator lines
    }

    let cellValues: string[] = [];
    if (isMarkdownTable) {
      cellValues = splitMarkdownRow(line);
    } else {
      cellValues = splitDelimitedRow(line, delimiter);
    }

    // Ensure cell count matches header count without shifting
    const targetLength = detectedHeaders.length;
    while (cellValues.length < targetLength) {
      cellValues.push('');
    }

    const rowObj: Record<string, string> = {};
    detectedHeaders.forEach((header, colIndex) => {
      rowObj[header] = (cellValues[colIndex] || '').trim();
    });

    rawRows.push(rowObj);
  }

  // Delegate to central WOFieldMappingEngine
  const engineResult = processRawImportWithEngine(
    rawRows,
    existingWoNumbers,
    options.contractors || [],
    options.coverageAreas || [],
    MASTER_CANONICAL_FIELDS
  );

  return {
    totalDetected: engineResult.parsedRows.length,
    validCount: engineResult.validCount,
    problematicCount: engineResult.problematicCount,
    duplicateCount: engineResult.duplicateCount,
    unrecognizedHeaders: engineResult.unrecognizedHeaders,
    detectedHeaders: engineResult.detectedHeaders,
    parsedRows: engineResult.parsedRows,
    detectedContractors: engineResult.detectedContractors,
    newCoverageAreas: engineResult.newCoverageAreas
  };
}

/**
 * Splits a Markdown table row by pipe '|', correctly preserving empty cells between pipes.
 */
function splitMarkdownRow(line: string): string[] {
  let trimmed = line.trim();
  if (trimmed.startsWith('|')) {
    trimmed = trimmed.substring(1);
  }
  if (trimmed.endsWith('|')) {
    trimmed = trimmed.substring(0, trimmed.length - 1);
  }
  return trimmed.split('|').map(cell => cell.trim());
}

/**
 * Checks if a string line is a markdown separator (e.g., |---|---|:---:|)
 */
function isMarkdownSeparator(line: string): boolean {
  const stripped = line.replace(/[|\s\-:]/g, '');
  return stripped.length === 0 && line.includes('-');
}

/**
 * Splits delimited text handling quoted cells
 */
function splitDelimitedRow(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = '';
  let insideQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"' || char === "'") {
      insideQuotes = !insideQuotes;
    } else if (char === delimiter && !insideQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}
