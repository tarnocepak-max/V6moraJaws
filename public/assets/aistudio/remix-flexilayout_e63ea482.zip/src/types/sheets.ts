export interface GoogleSheetsConfig {
  enabled: boolean;
  spreadsheetId: string;
  spreadsheetUrl?: string;
  spreadsheetTitle?: string;
  sheetName: string;
  accountEmail?: string;
  accountName?: string;
  syncInterval: number; // in minutes (e.g. 5, 10, 15, 30, 60)
  syncDirection: 'both' | 'export_only' | 'import_only';
  autoExportOnStatusChange: boolean;
  autoRegisterContractors: boolean;
  lastSyncAt: string | null;
  lastSyncStatus: 'idle' | 'syncing' | 'success' | 'error';
  lastSyncMessage: string | null;
  syncedRowCount: number;
  lastPulledCount: number;
  lastPushedCount: number;
}

export interface GoogleSpreadsheetMeta {
  id: string;
  title: string;
  url: string;
  sheets: string[];
}

export interface SheetSyncResult {
  success: boolean;
  message: string;
  pulledCount?: number;
  pushedCount?: number;
  newContractorsCount?: number;
  error?: string;
  timestamp: string;
}

export const DEFAULT_SHEETS_CONFIG: GoogleSheetsConfig = {
  enabled: true,
  spreadsheetId: '',
  spreadsheetUrl: '',
  spreadsheetTitle: 'MoraJaws Live Work Orders - rayhanafirzanx@gmail.com',
  sheetName: 'Work_Orders',
  accountEmail: 'rayhanafirzanx@gmail.com',
  accountName: 'Rayhan Afirzan',
  syncInterval: 10,
  syncDirection: 'both',
  autoExportOnStatusChange: true,
  autoRegisterContractors: true,
  lastSyncAt: null,
  lastSyncStatus: 'idle',
  lastSyncMessage: null,
  syncedRowCount: 0,
  lastPulledCount: 0,
  lastPushedCount: 0
};
