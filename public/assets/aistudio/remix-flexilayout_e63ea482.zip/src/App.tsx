import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { UIConfigProvider, useUIConfig } from './context/UIConfigContext';
import { ToastProvider } from './context/ToastContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { TicketsTable } from './components/tickets/TicketsTable';
import { TextToTableImporter } from './components/textToTable/TextToTableImporter';
import { TemplateBuilder } from './components/whatsapp/TemplateBuilder';
import { UIConfigurationBuilder } from './components/uiBuilder/UIConfigurationBuilder';
import { WorkflowManager } from './components/workflows/WorkflowManager';
import { LeaderPortal } from './components/portals/LeaderPortal';
import { InstallerPortal } from './components/portals/InstallerPortal';
import { AuditLogViewer } from './components/audit/AuditLogViewer';
import { SystemSettings } from './components/settings/SystemSettings';
import { TicketDetailModal } from './components/tickets/TicketDetailModal';
import { WhatsAppSendModal } from './components/whatsapp/WhatsAppSendModal';
import { AndroidBottomNav } from './components/layout/AndroidBottomNav';
import { UserManagementView } from './components/users/UserManagementView';
import { GoogleSheetsSyncView } from './components/sheets/GoogleSheetsSyncView';
import { OfflineSyncProvider } from './context/OfflineSyncContext';
import { OfflineSyncModal } from './components/offline/OfflineSyncModal';
import { OfflineBanner } from './components/offline/OfflineBanner';
import { StaffLoginPortal } from './components/auth/StaffLoginPortal';
import { DatabaseManagementView } from './components/database/DatabaseManagementView';
import { Ticket } from './types';
import { Menu, Database } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentUser, isLoggedIn, openOfflineSyncCenter } = useApp();
  const { config, setSidebarState, isMobileView } = useUIConfig();
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (currentUser.role === 'installer') return 'installer_portal';
    if (currentUser.role === 'leader') return 'leader_portal';
    if (currentUser.role === 'dispatch') return 'tickets';
    return 'dashboard';
  });
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [detailDefaultTab, setDetailDefaultTab] = useState<'overview' | 'report' | 'chat' | 'history'>('overview');
  const [whatsAppTicket, setWhatsAppTicket] = useState<Ticket | null>(null);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  // Unauthenticated Staff Protection: Render dedicated Staff Login Portal
  if (!isLoggedIn) {
    return (
      <StaffLoginPortal
        onLoginSuccess={(role) => {
          if (role === 'installer') setActiveTab('installer_portal');
          else if (role === 'leader') setActiveTab('leader_portal');
          else if (role === 'dispatch') setActiveTab('tickets');
          else setActiveTab('dashboard');
        }}
      />
    );
  }

  const handleOpenTicketDetail = (ticket: Ticket, defaultTab: 'overview' | 'report' | 'chat' | 'history' = 'overview') => {
    setSelectedTicket(ticket);
    setDetailDefaultTab(defaultTab);
    setIsDetailModalOpen(true);
  };

  const handleOpenWhatsAppModal = (ticket: Ticket) => {
    setWhatsAppTicket(ticket);
    setIsWhatsAppModalOpen(true);
  };

  const isFullWidth = config.global.contentWidth === 'full';
  const currentSidebarState = config.global.sidebarState || (config.global.sidebarCollapsed ? 'minimized' : 'expanded');

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors relative`}>
      {/* Top Header */}
      <Header activeTab={activeTab} onNavigate={tab => setActiveTab(tab)} />

      {/* Main Workspace Frame */}
      <div className="flex-1 flex overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onNavigate={tab => setActiveTab(tab)}
          sidebarState={currentSidebarState}
          onChangeState={state => setSidebarState(state)}
        />

        {/* Floating Open Menu Button when sidebar is closed and not in mobile bottom nav mode */}
        {currentSidebarState === 'closed' && !isDetailModalOpen && !isWhatsAppModalOpen && (!isMobileView || config.device?.android?.showBottomNavigation === false) && (
          <button
            onClick={() => setSidebarState('expanded')}
            className="fixed bottom-6 left-6 z-30 flex items-center gap-2 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-full shadow-lg transition-transform hover:scale-105"
            title="Buka Menu Navigasi"
          >
            <Menu className="w-4 h-4" />
            <span>Buka Menu</span>
          </button>
        )}

        {/* Content Viewport with mobile bottom navigation spacing */}
        <main className={`flex-1 overflow-y-auto p-3 sm:p-6 lg:p-8 ${
          isMobileView && config.device?.android?.showBottomNavigation !== false ? 'pb-24' : ''
        }`}>
          <div className={isFullWidth || (config.device?.mode === 'pc' && config.device?.pc?.wideScreenFullWidth) ? 'w-full' : 'max-w-7xl mx-auto'}>
            {activeTab === 'dashboard' && <DashboardOverview onNavigate={tab => setActiveTab(tab)} />}
            {activeTab === 'tickets' && (
              <TicketsTable
                onSelectTicket={handleOpenTicketDetail}
                onOpenWhatsApp={handleOpenWhatsAppModal}
              />
            )}
            {activeTab === 'import' && (
              <TextToTableImporter onImportSuccess={() => setActiveTab('tickets')} />
            )}
            {activeTab === 'sheets_sync' && (currentUser.role === 'super_admin' ? (
              <GoogleSheetsSyncView />
            ) : (
              <DashboardOverview onNavigate={tab => setActiveTab(tab)} />
            ))}
            {activeTab === 'leader_portal' && (
              <LeaderPortal
                onSelectTicket={handleOpenTicketDetail}
                onOpenWhatsApp={handleOpenWhatsAppModal}
              />
            )}
            {activeTab === 'installer_portal' && (
              <InstallerPortal
                onSelectTicket={handleOpenTicketDetail}
                onOpenWhatsApp={handleOpenWhatsAppModal}
              />
            )}
            {activeTab === 'templates' && <TemplateBuilder />}
            {activeTab === 'workflows' && <WorkflowManager />}
            {activeTab === 'ui_builder' && <UIConfigurationBuilder />}
            {activeTab === 'audit_logs' && <AuditLogViewer />}
            {activeTab === 'settings' && <SystemSettings />}
            {activeTab === 'users' && <UserManagementView />}
            {activeTab === 'database_management' && currentUser.role === 'super_admin' && (
              <DatabaseManagementView />
            )}
            {activeTab === 'offline_sync' && (
              <div className="p-8 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 text-center space-y-4 max-w-2xl mx-auto">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shadow-inner">
                  <Database className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white">Pusat Sinkronisasi Database Offline</h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Sistem penyimpanan lokal IndexedDB dan antrean mutasi data saat berada di area tanpa sinyal internet.
                  </p>
                </div>
                <div className="pt-2">
                  <button
                    onClick={openOfflineSyncCenter}
                    className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-105 active:scale-95"
                  >
                    Buka Panel Kontrol Sinkronisasi
                  </button>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Android / Mobile Bottom Ergonomic Navigation */}
      {isMobileView && config.device?.android?.showBottomNavigation !== false && (
        <AndroidBottomNav
          activeTab={activeTab}
          onNavigate={tab => {
            setActiveTab(tab);
            if (currentSidebarState === 'expanded') {
              setSidebarState('closed');
            }
          }}
          isMenuOpen={currentSidebarState === 'expanded'}
          onToggleMenu={() => {
            setSidebarState(currentSidebarState === 'expanded' ? 'closed' : 'expanded');
          }}
        />
      )}

      {/* Modals & Offline Alerts */}
      <OfflineSyncModal />
      <OfflineBanner />

      <TicketDetailModal
        ticket={selectedTicket}
        isOpen={isDetailModalOpen}
        defaultTab={detailDefaultTab}
        onClose={() => {
          setIsDetailModalOpen(false);
          setSelectedTicket(null);
        }}
        onOpenWhatsApp={ticket => {
          setIsDetailModalOpen(false);
          handleOpenWhatsAppModal(ticket);
        }}
      />

      {whatsAppTicket && (
        <WhatsAppSendModal
          ticket={whatsAppTicket}
          isOpen={isWhatsAppModalOpen}
          onClose={() => {
            setIsWhatsAppModalOpen(false);
            setWhatsAppTicket(null);
          }}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <ToastProvider>
      <OfflineSyncProvider>
        <AppProvider>
          <UIConfigProvider>
            <MainLayout />
          </UIConfigProvider>
        </AppProvider>
      </OfflineSyncProvider>
    </ToastProvider>
  );
}
