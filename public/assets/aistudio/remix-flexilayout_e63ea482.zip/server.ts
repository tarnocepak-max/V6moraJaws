import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Standalone hashing function (matching client quickHash)
function hashPassword(password: string, salt: string = 'morajaws_secure_salt_2026'): string {
  let h = 0x811c9dc5;
  const str = `${salt}:${password}`;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return ('00000000' + (h >>> 0).toString(16)).slice(-8);
}

const DEFAULT_HASH = hashPassword('12345678');

// In-Memory Database Stores
interface ServerUser {
  id: string;
  name: string;
  username: string;
  email: string;
  role: 'super_admin' | 'dispatch' | 'leader' | 'installer';
  contractor?: string;
  contractorId?: string;
  area?: string;
  phone?: string;
  active: boolean;
  passwordHash: string;
  lastLoginAt?: string;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedBy?: string;
  deletionReason?: string;
  createdAt: string;
}

const SERVER_USERS: ServerUser[] = [
  {
    id: 'u-1',
    name: 'Alamsyah (Super Admin)',
    username: 'superadmin',
    email: 'admin@morajaws.net',
    role: 'super_admin',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-01T00:00:00Z'
  },
  {
    id: 'u-2',
    name: 'Rina Kartika (Dispatch)',
    username: 'dispatch_rina',
    email: 'rina@morajaws.net',
    phone: '081211112222',
    role: 'dispatch',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-05T00:00:00Z'
  },
  {
    id: 'u-3',
    name: 'Hendra Gunawan (Leader)',
    username: 'leader_hendra',
    email: 'hendra@mitrajaringan.co.id',
    phone: '081299887711',
    role: 'leader',
    contractor: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    area: 'Jakarta Selatan',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-10T00:00:00Z'
  },
  {
    id: 'u-4',
    name: 'Andi Saputra (Teknisi)',
    username: 'installer_andi',
    email: 'andi@mitrajaringan.co.id',
    phone: '081233445566',
    role: 'installer',
    contractor: 'PT Mitra Jaringan Solusi',
    contractorId: 'c-1',
    area: 'Jakarta Selatan',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-12T00:00:00Z'
  },
  {
    id: 'u-5',
    name: 'Bambang Sudiro (Leader)',
    username: 'leader_bambang',
    email: 'bambang@kencanasolusindo.com',
    phone: '081388776622',
    role: 'leader',
    contractor: 'PT Kencana Solusindo',
    contractorId: 'c-2',
    area: 'Jakarta Barat',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-15T00:00:00Z'
  },
  {
    id: 'u-6',
    name: 'Dedi Kurniawan (Teknisi)',
    username: 'installer_dedi',
    email: 'dedi@kencanasolusindo.com',
    phone: '085811223344',
    role: 'installer',
    contractor: 'PT Kencana Solusindo',
    contractorId: 'c-2',
    area: 'Jakarta Barat',
    active: true,
    passwordHash: DEFAULT_HASH,
    createdAt: '2026-01-16T00:00:00Z'
  }
];

let serverAuditLogs: any[] = [
  {
    id: 'log_init',
    action: 'Server Initialized',
    entity: 'auth',
    entityId: 'sys-0',
    details: 'MoraJaws Dispatch backend initialized with Account-Category RBAC and Super Admin deletion policy',
    performedBy: 'System',
    userRole: 'super_admin',
    timestamp: new Date().toISOString()
  }
];

// Helper to log server audit entries
function logServerAudit(action: string, entity: string, entityId: string, details: string, user?: ServerUser | null) {
  const entry = {
    id: 'log_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
    action,
    entity,
    entityId,
    details,
    performedBy: user ? user.name : 'Anonymous / System',
    userRole: user ? user.role : 'system',
    timestamp: new Date().toISOString()
  };
  serverAuditLogs.unshift(entry);
  if (serverAuditLogs.length > 1000) serverAuditLogs.pop();
  return entry;
}

// Standalone phone & WhatsApp helpers
function normalizePhoneNumber(phone: string | undefined | null): string {
  if (!phone) return '';
  let digits = String(phone).replace(/\D/g, '');
  if (digits.startsWith('0')) {
    digits = '62' + digits.substring(1);
  } else if (digits.startsWith('8')) {
    digits = '62' + digits;
  } else if (!digits.startsWith('62') && digits.length >= 8) {
    digits = '62' + digits;
  }
  return digits;
}

function isValidPhoneNumber(phone: string): boolean {
  const normalized = normalizePhoneNumber(phone);
  return /^62[2-9]\d{7,12}$/.test(normalized);
}

function renderWhatsAppMessage(templateBody: string, ticket: any) {
  const missingVariables: string[] = [];
  const varMap: Record<string, string> = {
    customer_name: ticket?.customerName || ticket?.endUserName || '',
    customer_id: ticket?.idCustomer || ticket?.customerId || '',
    customer_phone: ticket?.customerPhone || '',
    wo_number: ticket?.woNumber || ticket?.workOrderNumber || '',
    ticket_number: ticket?.ticketNumber || ticket?.woNumber || '',
    ticket_category: ticket?.ticketCategory || '',
    slot_time: ticket?.slotTime || '',
    street_name: ticket?.streetName || '',
    street_alternatif: ticket?.streetAlternatif || '',
    cluster_name: ticket?.clusterName || '',
    area: ticket?.area || '',
    contractor_name: ticket?.contactorName || ticket?.contractorName || '',
    contactor_name: ticket?.contactorName || ticket?.contractorName || '',
    installer_name: ticket?.installerName || '',
    date: ticket?.appointmentDate || ticket?.date || '',
    fdt_code: ticket?.fdtCode || '',
    fat_code: ticket?.fatCode || ''
  };

  if (ticket?.additionalFields) {
    Object.entries(ticket.additionalFields).forEach(([k, v]) => {
      varMap[k.toLowerCase()] = String(v || '');
    });
  }

  const rendered = (templateBody || '').replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_match: string, varName: string) => {
    const key = varName.toLowerCase();
    const val = varMap[key];
    if (val === undefined || val === null || val.trim() === '') {
      missingVariables.push(varName);
      return '';
    }
    return val;
  });

  return {
    renderedText: rendered,
    missingVariables: Array.from(new Set(missingVariables)),
    hasWarnings: missingVariables.length > 0
  };
}

function buildWhatsAppClickToChatUrl(phone: string, messageText: string): { url: string; error?: string } {
  const normalizedPhone = normalizePhoneNumber(phone);
  if (!isValidPhoneNumber(normalizedPhone)) {
    return {
      url: '',
      error: `Nomor telepon tidak valid untuk WhatsApp Indonesia (${phone || 'Kosong'}). Pastikan diawali 08/628 dan minimal 10 digit.`
    };
  }
  const encodedMessage = encodeURIComponent(messageText || '');
  return { url: `https://wa.me/${normalizedPhone}?text=${encodedMessage}` };
}

// Standalone work order text parser
function parseWorkOrderText(rawText: string, _options: any = {}) {
  if (!rawText || !rawText.trim()) {
    return {
      totalDetected: 0,
      validCount: 0,
      problematicCount: 0,
      duplicateCount: 0,
      unrecognizedHeaders: [],
      detectedHeaders: [],
      parsedRows: []
    };
  }

  const lines = rawText
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);

  if (lines.length === 0) {
    return {
      totalDetected: 0,
      validCount: 0,
      problematicCount: 0,
      duplicateCount: 0,
      unrecognizedHeaders: [],
      detectedHeaders: [],
      parsedRows: []
    };
  }

  const firstLine = lines[0];
  const isMarkdownTable = firstLine.includes('|');
  const delimiter = isMarkdownTable ? '|' : (firstLine.includes('\t') ? '\t' : (firstLine.includes(';') ? ';' : ','));

  const splitMarkdownRow = (line: string): string[] => {
    let cleaned = line.trim();
    if (cleaned.startsWith('|')) cleaned = cleaned.substring(1);
    if (cleaned.endsWith('|')) cleaned = cleaned.substring(0, cleaned.length - 1);
    return cleaned.split('|').map(c => c.trim());
  };

  const isMarkdownSeparator = (line: string): boolean => {
    return /^\|?(\s*:?-+:?\s*\|)+\s*:?-+:?\s*\|?$/.test(line.trim());
  };

  const splitDelimitedRow = (line: string, delim: string): string[] => {
    return line.split(delim).map(c => c.trim());
  };

  let rawHeaders: string[] = [];
  let dataLinesStartIndex = 1;

  if (isMarkdownTable) {
    rawHeaders = splitMarkdownRow(firstLine);
    if (lines.length > 1 && isMarkdownSeparator(lines[1])) {
      dataLinesStartIndex = 2;
    }
  } else {
    rawHeaders = splitDelimitedRow(firstLine, delimiter);
  }

  const detectedHeaders = rawHeaders.map((h, i) => h.trim() || `UNNAMED_COLUMN_${i + 1}`);
  const parsedRows: any[] = [];
  let validCount = 0;
  let problematicCount = 0;

  for (let i = dataLinesStartIndex; i < lines.length; i++) {
    const line = lines[i];
    if (isMarkdownTable && isMarkdownSeparator(line)) continue;
    const cells = isMarkdownTable ? splitMarkdownRow(line) : splitDelimitedRow(line, delimiter);
    const rawRecord: Record<string, string> = {};
    detectedHeaders.forEach((h, idx) => {
      rawRecord[h] = cells[idx] || '';
    });
    const isValid = Object.values(rawRecord).some(v => v.trim() !== '');
    if (isValid) validCount++; else problematicCount++;
    parsedRows.push({
      rowIndex: i,
      rawRecord,
      isValid,
      validationErrors: []
    });
  }

  return {
    totalDetected: parsedRows.length,
    validCount,
    problematicCount,
    duplicateCount: 0,
    unrecognizedHeaders: [],
    detectedHeaders,
    parsedRows
  };
}

// -------------------------------------------------------------
// Authentication & RBAC Middleware
// -------------------------------------------------------------
interface AuthenticatedRequest extends Request {
  user?: ServerUser;
}

function resolveUserFromHeader(req: AuthenticatedRequest, _res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const userHeader = req.headers['x-user-id'] || req.headers['x-username'];

  let found: ServerUser | undefined;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    // Token format: mora_{userId}_{timestamp}_{rand}
    const parts = token.split('_');
    if (parts.length >= 2) {
      found = SERVER_USERS.find(u => u.id === parts[1]);
    }
  }

  if (!found && userHeader) {
    const identifier = String(userHeader).toLowerCase().trim();
    found = SERVER_USERS.find(
      u => u.id === identifier || u.username.toLowerCase() === identifier || u.email.toLowerCase() === identifier
    );
  }

  // Default fallback to superadmin for local convenience if headers omitted
  if (!found) {
    found = SERVER_USERS[0];
  }

  req.user = found;
  next();
}

function requireSuperAdminForDeletion(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || req.user.role !== 'super_admin') {
    return res.status(403).json({
      error: 'Akses Ditolak: Penghapusan data atau akun pengguna hanya dapat dilakukan oleh Super Admin.',
      code: 'REQUIRE_SUPER_ADMIN'
    });
  }
  next();
}

function requireImportPermission(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user || (req.user.role !== 'super_admin' && req.user.role !== 'dispatch')) {
    return res.status(403).json({
      error: 'Akses Ditolak: Otoritas import data Work Order hanya diberikan kepada Super Admin dan Dispatch.',
      code: 'REQUIRE_IMPORT_PERMISSION'
    });
  }
  next();
}

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(resolveUserFromHeader);

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // --- Auth Endpoints ---
  app.post('/api/auth/login', (req: AuthenticatedRequest, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username dan kata sandi wajib diisi.' });
    }

    const cleanUser = String(username).trim().toLowerCase();
    const user = SERVER_USERS.find(
      u => (u.username.toLowerCase() === cleanUser || u.email.toLowerCase() === cleanUser) && !u.isDeleted
    );

    const attemptedHash = hashPassword(password);

    if (!user || user.passwordHash !== attemptedHash) {
      logServerAudit('Login Failed', 'auth', cleanUser, `Percobaan login gagal untuk: ${cleanUser}`, null);
      return res.status(401).json({ error: 'Kredensial login tidak valid. Periksa username dan kata sandi.' });
    }

    if (!user.active) {
      logServerAudit('Login Blocked', 'auth', user.id, `Akun nonaktif mencoba login: ${user.username}`, user);
      return res.status(403).json({ error: 'Akun Anda telah dinonaktifkan oleh Administrator. Hubungi Super Admin.' });
    }

    user.lastLoginAt = new Date().toISOString();
    logServerAudit('Login Success', 'auth', user.id, `User ${user.name} (${user.role}) berhasil masuk ke sistem`, user);

    const token = `mora_${user.id}_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    const { passwordHash: _, ...safeUser } = user;

    res.json({
      success: true,
      token,
      user: safeUser
    });
  });

  app.post('/api/auth/logout', (req: AuthenticatedRequest, res) => {
    if (req.user) {
      logServerAudit('Logout Success', 'auth', req.user.id, `User ${req.user.name} (${req.user.role}) logout dari sistem`, req.user);
    }
    res.json({ success: true, message: 'Sesi berhasil diakhiri' });
  });

  app.get('/api/auth/me', (req: AuthenticatedRequest, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Sesi kedaluwarsa atau belum terautentikasi' });
    }
    const { passwordHash: _, ...safeUser } = req.user;
    res.json({ user: safeUser });
  });

  // --- Scoped Work Order Endpoints (Backend RBAC Enforcement) ---
  app.get('/api/tickets', (req: AuthenticatedRequest, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Tidak terautentikasi' });
    }

    const { role, contractor, area, name } = req.user;
    res.json({
      role,
      user: name,
      scope: role === 'super_admin' || role === 'dispatch' ? 'all' : (role === 'leader' ? `contractor:${contractor}` : `installer:${name}`),
      serverTime: new Date().toISOString()
    });
  });

  // --- User Management Endpoints (Super Admin Only) ---
  app.get('/api/users', (req: AuthenticatedRequest, res) => {
    if (req.user?.role !== 'super_admin') {
      return res.status(403).json({ error: 'Akses Ditolak: Hanya Super Admin yang dapat melihat daftar pengguna.' });
    }
    const activeUsers = SERVER_USERS.filter(u => !u.isDeleted).map(u => {
      const { passwordHash: _, ...safe } = u;
      return safe;
    });
    res.json({ users: activeUsers });
  });

  app.post('/api/users', (req: AuthenticatedRequest, res) => {
    if (req.user?.role !== 'super_admin') {
      return res.status(403).json({ error: 'Akses Ditolak: Hanya Super Admin yang dapat membuat akun pengguna baru.' });
    }
    const { name, username, email, phone, role, contractor, contractorId, area } = req.body;
    if (!name || !username || !role) {
      return res.status(400).json({ error: 'Nama, username, dan role akun wajib diisi.' });
    }

    const cleanUsername = username.trim().toLowerCase();
    if (SERVER_USERS.some(u => u.username.toLowerCase() === cleanUsername && !u.isDeleted)) {
      return res.status(409).json({ error: `Username ${cleanUsername} sudah digunakan.` });
    }

    const newUser: ServerUser = {
      id: 'u-' + Date.now(),
      name: name.trim(),
      username: cleanUsername,
      email: email?.trim() || `${cleanUsername}@morajaws.net`,
      phone: phone?.trim(),
      role,
      contractor,
      contractorId,
      area,
      active: true,
      passwordHash: DEFAULT_HASH,
      createdAt: new Date().toISOString()
    };

    SERVER_USERS.push(newUser);
    logServerAudit('User Created', 'auth', newUser.id, `Super Admin ${req.user.name} membuat akun: ${newUser.name} (@${newUser.username}) [${newUser.role}]`, req.user);

    const { passwordHash: _, ...safeUser } = newUser;
    res.status(201).json({ success: true, user: safeUser });
  });

  app.delete('/api/users/:id', requireSuperAdminForDeletion, (req: AuthenticatedRequest, res) => {
    const { id } = req.params;
    const { reason, permanent } = req.body;

    if (!reason || reason.trim().length < 5) {
      return res.status(400).json({ error: 'Alasan penghapusan akun wajib disertakan minimal 5 karakter.' });
    }

    const userIndex = SERVER_USERS.findIndex(u => u.id === id);
    if (userIndex === -1) {
      return res.status(404).json({ error: 'Pengguna tidak ditemukan.' });
    }

    const targetUser = SERVER_USERS[userIndex];
    if (targetUser.id === req.user?.id) {
      return res.status(400).json({ error: 'Anda tidak dapat menghapus akun Anda sendiri saat sedang login.' });
    }

    if (permanent) {
      SERVER_USERS.splice(userIndex, 1);
      logServerAudit('User Permanently Deleted', 'auth', id, `Akun ${targetUser.name} (@${targetUser.username}) dihapus permanen oleh Super Admin. Alasan: ${reason}`, req.user);
    } else {
      // Soft Delete
      targetUser.isDeleted = true;
      targetUser.active = false;
      targetUser.deletedAt = new Date().toISOString();
      targetUser.deletedBy = req.user?.name;
      targetUser.deletionReason = reason;
      logServerAudit('User Soft Deleted', 'auth', id, `Akun ${targetUser.name} dinonaktifkan & ditandai terhapus (soft delete). Alasan: ${reason}`, req.user);
    }

    res.json({ success: true, message: `Akun ${targetUser.name} berhasil dihapus.` });
  });

  // --- Text-to-Table Parse & Import (Strict RBAC: Super Admin & Dispatch Only) ---
  app.post('/api/text-to-table/parse', requireImportPermission, (req, res) => {
    try {
      const { text, options } = req.body;
      const result = parseWorkOrderText(text, options);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Failed to parse text' });
    }
  });

  // WhatsApp click-to-chat preview
  app.post('/api/whatsapp/preview', (req, res) => {
    try {
      const { templateBody, ticket } = req.body;
      const result = renderWhatsAppMessage(templateBody, ticket);
      const urlResult = buildWhatsAppClickToChatUrl(ticket?.customerPhone || '', result.renderedText);
      res.json({
        renderedText: result.renderedText,
        missingVariables: result.missingVariables,
        url: urlResult.url,
        urlError: urlResult.error
      });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  // Audit logs (Super Admin Only)
  app.get('/api/audit-logs', (req: AuthenticatedRequest, res) => {
    if (req.user?.role !== 'super_admin') {
      return res.status(403).json({ error: 'Akses Ditolak: Hanya Super Admin yang berwenang meninjau audit log sistem.' });
    }
    res.json({ logs: serverAuditLogs });
  });

  app.post('/api/audit-logs', (req: AuthenticatedRequest, res) => {
    const { action, entity, entityId, details } = req.body;
    const entry = logServerAudit(action, entity, entityId, details, req.user || null);
    res.json(entry);
  });

  // Mount Vite middleware in development or serve static in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MoraJaws Dispatch Management Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
