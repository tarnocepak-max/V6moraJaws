/**
 * MoraJaws Deterministic Appointment Date Engine
 *
 * Strict parsing and validation for Appointment Date:
 * - Zero timezone shift (pure string / UTC date-only calculation)
 * - Supports:
 *   - YYYY-MM-DD (ISO date-only or timestamp)
 *   - DD/MM/YYYY, DD-MM-YYYY (standard Indonesian FTTH format)
 *   - MM/DD/YYYY, MM-DD-YYYY
 *   - Excel / Google Sheets serial date numbers (e.g. 45583)
 * - Never fallbacks to current date, upload date, or dummy date
 * - Returns null when missing or invalid, with clear error explanations
 */

export interface DateParseResult {
  date: string | null; // Standardized "YYYY-MM-DD" or null
  rawValue: string;
  isValid: boolean;
  isEmpty: boolean;
  error?: string;
  formatDetected?: string;
}

function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

function getDaysInMonth(year: number, month: number): number {
  switch (month) {
    case 2:
      return isLeapYear(year) ? 29 : 28;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    default:
      return 31;
  }
}

/**
 * Deterministically parses an appointment date value without timezone shifts.
 */
export function parseAppointmentDate(input: unknown): DateParseResult {
  if (input === null || input === undefined) {
    return {
      date: null,
      rawValue: '',
      isValid: true,
      isEmpty: true
    };
  }

  const rawStr = String(input).trim();
  if (rawStr === '' || rawStr === '-' || rawStr === 'null' || rawStr === 'undefined') {
    return {
      date: null,
      rawValue: rawStr,
      isValid: true,
      isEmpty: true
    };
  }

  // 1. Excel / Google Sheets Serial Date Number (e.g., 45583, "45583", 45583.5)
  // Typically serial dates for years 2000-2050 are between 36526 and 55153
  const numericVal = typeof input === 'number' ? input : (!isNaN(Number(rawStr)) ? Number(rawStr) : NaN);
  if (!isNaN(numericVal) && numericVal >= 30000 && numericVal <= 70000) {
    try {
      const serialInt = Math.floor(numericVal);
      // Excel epoch starts at 1899-12-30 (accounting for 1900 leap bug)
      // Days from 1970-01-01 to 1899-12-30 is 25569 days
      const utcMs = (serialInt - 25569) * 86400000;
      const d = new Date(utcMs);
      const year = d.getUTCFullYear();
      const month = d.getUTCMonth() + 1;
      const day = d.getUTCDate();

      if (year >= 2000 && year <= 2099) {
        const formatted = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        return {
          date: formatted,
          rawValue: rawStr,
          isValid: true,
          isEmpty: false,
          formatDetected: 'excel_serial_number'
        };
      }
    } catch {
      // Fall through to string regex checks
    }
  }

  // 2. ISO format YYYY-MM-DD or YYYY-MM-DDTHH:mm:ss... or YYYY/MM/DD
  const isoMatch = rawStr.match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})/);
  if (isoMatch) {
    const year = parseInt(isoMatch[1], 10);
    const month = parseInt(isoMatch[2], 10);
    const day = parseInt(isoMatch[3], 10);

    if (year < 2000 || year > 2099) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Tahun ${year} berada di luar rentang operasional yang valid (2000-2099).`
      };
    }

    if (month < 1 || month > 12) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Bulan ${month} tidak valid (harus 1-12).`
      };
    }

    const maxDays = getDaysInMonth(year, month);
    if (day < 1 || day > maxDays) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Tanggal ${day} tidak valid untuk bulan ${month}/${year} (maksimal ${maxDays} hari).`
      };
    }

    const formatted = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return {
      date: formatted,
      rawValue: rawStr,
      isValid: true,
      isEmpty: false,
      formatDetected: 'iso_yyyy_mm_dd'
    };
  }

  // 3. Delimited Date: DD/MM/YYYY, MM/DD/YYYY, DD-MM-YYYY, DD.MM.YYYY
  const delimitedMatch = rawStr.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/);
  if (delimitedMatch) {
    const firstPart = parseInt(delimitedMatch[1], 10);
    const secondPart = parseInt(delimitedMatch[2], 10);
    const year = parseInt(delimitedMatch[3], 10);

    if (year < 2000 || year > 2099) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Tahun ${year} berada di luar rentang operasional valid.`
      };
    }

    let day: number;
    let month: number;
    let format = 'dd_mm_yyyy';

    if (firstPart > 12 && secondPart <= 12) {
      // Unambiguous DD/MM/YYYY
      day = firstPart;
      month = secondPart;
      format = 'dd_mm_yyyy';
    } else if (secondPart > 12 && firstPart <= 12) {
      // Unambiguous MM/DD/YYYY
      month = firstPart;
      day = secondPart;
      format = 'mm_dd_yyyy';
    } else if (firstPart <= 12 && secondPart <= 12) {
      // Standard Indonesian telecom convention: DD/MM/YYYY
      day = firstPart;
      month = secondPart;
      format = 'dd_mm_yyyy_standard';
    } else {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Komponen tanggal/bulan (${firstPart}/${secondPart}) tidak dapat dipetakan.`
      };
    }

    if (month < 1 || month > 12) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Bulan ${month} tidak valid.`
      };
    }

    const maxDays = getDaysInMonth(year, month);
    if (day < 1 || day > maxDays) {
      return {
        date: null,
        rawValue: rawStr,
        isValid: false,
        isEmpty: false,
        error: `Tanggal ${day} melebihi batas hari bulan ${month} (${maxDays} hari).`
      };
    }

    const formatted = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return {
      date: formatted,
      rawValue: rawStr,
      isValid: true,
      isEmpty: false,
      formatDetected: format
    };
  }

  // 4. Any unparseable string
  return {
    date: null,
    rawValue: rawStr,
    isValid: false,
    isEmpty: false,
    error: `Format appointment date "${rawStr}" tidak dikenali. Gunakan format resmi (DD/MM/YYYY atau YYYY-MM-DD).`
  };
}

/**
 * Formats a stored YYYY-MM-DD date for human display in Indonesian locale.
 * If null/empty, returns informative fallback: "Tanggal appointment belum tersedia"
 */
export function formatAppointmentDateDisplay(dateStr?: string | null): string {
  if (!dateStr || !dateStr.trim()) {
    return 'Tanggal appointment belum tersedia';
  }
  const clean = dateStr.trim();
  const match = clean.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!match) {
    // If not standard YYYY-MM-DD, try parsing
    const res = parseAppointmentDate(clean);
    if (res.date) {
      return formatAppointmentDateDisplay(res.date);
    }
    return clean;
  }

  const [_, yyyy, mm, dd] = match;
  const monthNames = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const mIndex = parseInt(mm, 10) - 1;
  const monthName = monthNames[mIndex] || mm;
  return `${parseInt(dd, 10)} ${monthName} ${yyyy}`;
}

export type ScheduleDateFilterMode = 'all' | 'today' | 'previous' | 'upcoming' | 'custom';

/**
 * Calculates current operational date string (YYYY-MM-DD) in Asia/Jakarta timezone (WIB).
 * Uses operational reference date or current calendar date.
 */
export function getOperationalTodayDate(overrideDate?: string): string {
  if (overrideDate && /^\d{4}-\d{2}-\d{2}$/.test(overrideDate.trim())) {
    return overrideDate.trim();
  }
  try {
    const dtf = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
    return dtf.format(new Date());
  } catch {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
}

/**
 * Checks if a ticket's appointment date matches the schedule filter against the operational reference date.
 * - 'today': ticket appointment date matches operational reference date exactly
 * - 'previous': ticket appointment date is before operational reference date
 * - 'upcoming': ticket appointment date is after operational reference date
 * - 'custom': within start and end date range
 * - 'all': all tickets
 */
export function matchesScheduleDateFilter(
  ticketAppointmentDate: string | undefined | null,
  mode: ScheduleDateFilterMode,
  referenceDate: string,
  customRange?: { start?: string; end?: string }
): boolean {
  if (mode === 'all') return true;

  const parsed = parseAppointmentDate(ticketAppointmentDate);
  const ticketDate = parsed.date;

  // Tickets without valid appointment date only match 'all'
  if (!ticketDate) {
    return false;
  }

  if (mode === 'today') {
    return ticketDate === referenceDate;
  }

  if (mode === 'previous') {
    return ticketDate < referenceDate;
  }

  if (mode === 'upcoming') {
    return ticketDate > referenceDate;
  }

  if (mode === 'custom' && customRange) {
    if (customRange.start && ticketDate < customRange.start) return false;
    if (customRange.end && ticketDate > customRange.end) return false;
    return true;
  }

  return true;
}

