import React, { useState } from 'react';
import { Ticket, TicketStatusWOInstaller, TechnicalReport } from '../../types/index.ts';
import { useApp } from '../../context/AppContext';
import { StatusInstallerBadge, StatusWhatsAppBadge, StatusAgentBadge } from '../common/Badge';
import { buildWhatsAppClickToChatUrl } from '../../services/whatsappService';
import { openCustomerAddressInGoogleMaps } from '../../services/mapsService';
import { TicketLiveChat } from '../chat/TicketLiveChat';
import {
  ArrowLeft,
  Phone,
  MessageSquare,
  MapPin,
  CheckCircle2,
  Navigation,
  Clock,
  Calendar,
  Building2,
  User,
  Wrench,
  Radio,
  Wifi,
  Copy,
  Check,
  AlertTriangle,
  Send,
  Save,
  Camera,
  ExternalLink,
  Layers,
  Sparkles,
  HelpCircle,
  FileText,
  MessageCircle,
  List
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface InstallerTicketFullviewProps {
  ticket: Ticket;
  onBack: () => void;
  onOpenWhatsApp: (ticket: Ticket) => void;
}

export const InstallerTicketFullview: React.FC<InstallerTicketFullviewProps> = ({
  ticket,
  onBack,
  onOpenWhatsApp
}) => {
  const {
    updateTicketStatus,
    saveTechnicalReport,
    rootCauseCategories,
    workResultsList,
    currentUser,
    getTicketUnreadCount
  } = useApp();
  const { toast } = useToast();

  const [copiedAddress, setCopiedAddress] = useState(false);
  const [activeTab, setActiveTab] = useState<'details' | 'report' | 'chat'>('details');

  // Technical report state
  const existingReport = ticket.technicalReport;
  const [opticalPowerDbm, setOpticalPowerDbm] = useState(existingReport?.opticalPowerDbm || '-19.2');
  const [mainCategory, setMainCategory] = useState(existingReport?.mainCategory || (rootCauseCategories[0]?.name || 'Wi-Fi / Fiber Optic'));
  const [rootCause, setRootCause] = useState(existingReport?.rootCause || 'Konektor FO Redaman Tinggi');
  const [workResult, setWorkResult] = useState(existingReport?.workResult || (workResultsList[0] || 'Instalasi Selesai Sesuai Standar'));
  const [technicalDescription, setTechnicalDescription] = useState(existingReport?.technicalDescription || '');
  const [correctiveAction, setCorrectiveAction] = useState(existingReport?.correctiveAction || '');
  const [usedMaterials, setUsedMaterials] = useState(existingReport?.usedMaterials || 'Dropcore 150m, 1 Roset, 2 Fast Connector');
  const [deviceSerialNumber, setDeviceSerialNumber] = useState(existingReport?.deviceSerialNumber || ticket.ontSerialNumber || '');
  const [photoPreview, setPhotoPreview] = useState<string | null>(existingReport?.photoAfterUrl || null);

  const unreadChatCount = getTicketUnreadCount(ticket.id);

  // Quick WhatsApp link beside customer phone
  const waUrlObj = buildWhatsAppClickToChatUrl(
    ticket.customerPhone,
    `Halo ${ticket.customerName}, saya teknisi ${currentUser.name || 'MoraJaws'} terkait pemasangan WO ${ticket.woNumber} hari ini.`
  );

  const handleCopyAddress = () => {
    const fullAddr = `${ticket.streetName || ticket.address || ''}, ${ticket.clusterName || ''}, ${ticket.area || ''}`.trim();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(fullAddr);
      setCopiedAddress(true);
      toast.success('Alamat lengkap berhasil disalin ke clipboard.', 'Disalin');
      setTimeout(() => setCopiedAddress(false), 2000);
    }
  };

  const handleOpenMaps = () => {
    openCustomerAddressInGoogleMaps(ticket, () => {
      toast.warning('Alamat pelanggan belum tersedia untuk pencarian Google Maps.', 'Google Maps');
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
        toast.info('Foto dokumentasi pengerjaan berhasil dimuat.', 'Foto Dipilih');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleQuickStatusChange = (newStatus: TicketStatusWOInstaller) => {
    updateTicketStatus(ticket.id, undefined, newStatus, `Status diperbarui oleh teknisi ${currentUser.name}: ${newStatus}`);
    toast.success(`Status tiket diubah menjadi: ${newStatus}`, 'Status Diperbarui');
  };

  const handleOtwLokasiWithMaps = () => {
    handleQuickStatusChange('En Route');
    handleOpenMaps();
  };

  const handleSaveReport = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const res = saveTechnicalReport(ticket.id, {
      mainCategory,
      rootCause,
      workResult,
      technicalDescription: technicalDescription || `Pengerjaan tiket ${ticket.woNumber} oleh ${currentUser.name}`,
      correctiveAction: correctiveAction || 'Penyambungan ulang fast connector dan pengujian redaman OPM',
      opticalPowerDbm,
      usedMaterials,
      deviceSerialNumber,
      photoAfterUrl: photoPreview || undefined
    });
    if (res.success) {
      toast.success('Laporan teknis berhasil disimpan dan dicatat ke sistem.', 'Laporan Tersimpan');
    } else {
      toast.error(res.error || 'Gagal menyimpan laporan teknis.', 'Kesalahan');
    }
  };

  const handleMarkCompleted = () => {
    handleSaveReport();
    updateTicketStatus(ticket.id, 'Resolved', 'Completed', `Pekerjaan telah rampung dan diselesaikan oleh ${currentUser.name}. OPM: ${opticalPowerDbm} dBm`);
    toast.success(`Tiket ${ticket.woNumber} berhasil diselesaikan.`, 'Pekerjaan Rampung');
  };

  return (
    <div className="bg-[#F5F1FF] dark:bg-[#140827] min-h-screen -m-3 sm:-m-6 lg:-m-8 flex flex-col text-[#21183A] dark:text-[#F5F1FF]">
      {/* Top Sticky Header */}
      <div className="sticky top-0 z-30 bg-white/95 dark:bg-[#1a0f30]/95 backdrop-blur-md border-b border-[#D8CCF3] dark:border-[#3B1D78] px-4 sm:px-6 py-3.5 flex items-center justify-between gap-3 shadow-xs">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onBack}
            className="p-2 -ml-1 rounded-xl text-[#3B1D78] dark:text-[#E9E1FF] hover:bg-[#E9E1FF] dark:hover:bg-[#3B1D78] transition-colors flex items-center gap-1.5 text-xs font-bold shrink-0 cursor-pointer"
            title="Kembali ke Daftar WO"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Kembali</span>
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono font-extrabold text-sm sm:text-base text-[#3B1D78] dark:text-[#E9E1FF]">
                {ticket.woNumber}
              </span>
              <StatusInstallerBadge status={ticket.statusWOInstaller} />
              <StatusAgentBadge status={ticket.statusWOAgent} />
            </div>
            <div className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3] truncate mt-0.5">
              Jadwal Appointment: <strong className="text-[#3B1D78] dark:text-white font-mono">{ticket.appointmentDate || ticket.date}</strong> · Slot: <strong className="text-[#5B35B1] dark:text-[#8064D9] font-mono">{ticket.slotTime}</strong>
            </div>
          </div>
        </div>

        {/* Header Tab Switcher (Details, Report, Live Chat) */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setActiveTab('details')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 border cursor-pointer ${
              activeTab === 'details'
                ? 'bg-[#3B1D78] text-white border-[#3B1D78] shadow-xs'
                : 'bg-white dark:bg-[#1f113a] text-[#756B8D] dark:text-[#D8CCF3] border-[#D8CCF3] dark:border-[#3B1D78] hover:bg-[#E9E1FF]/50'
            }`}
          >
            <List className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Info WO</span>
          </button>

          <button
            onClick={() => setActiveTab('report')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 border cursor-pointer ${
              activeTab === 'report'
                ? 'bg-[#3B1D78] text-white border-[#3B1D78] shadow-xs'
                : 'bg-white dark:bg-[#1f113a] text-[#756B8D] dark:text-[#D8CCF3] border-[#D8CCF3] dark:border-[#3B1D78] hover:bg-[#E9E1FF]/50'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Laporan</span>
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`relative px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 border cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-[#5B35B1] text-white border-[#5B35B1] shadow-xs'
                : 'bg-white dark:bg-[#1f113a] text-[#756B8D] dark:text-[#D8CCF3] border-[#D8CCF3] dark:border-[#3B1D78] hover:bg-[#E9E1FF]/50'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chat</span>
            {unreadChatCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
            )}
          </button>
        </div>
      </div>

      {/* Main Content Viewport */}
      <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto w-full pb-36 space-y-6">
        {/* VIEW 1: LIVE CHAT TAB */}
        {activeTab === 'chat' && (
          <div className="bg-white dark:bg-[#1f113a] rounded-2xl border-2 border-[#D8CCF3] dark:border-[#3B1D78] shadow-sm overflow-hidden">
            <div className="px-5 py-3.5 bg-[#E9E1FF]/60 dark:bg-[#251247] border-b border-[#D8CCF3] dark:border-[#3B1D78] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                <h3 className="font-bold text-xs uppercase tracking-wider text-[#3B1D78] dark:text-[#E9E1FF]">
                  Live Chat Koordinasi Teknisi & Dispatch (WO: {ticket.woNumber})
                </h3>
              </div>
              <span className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3]">
                Terhubung Real-Time
              </span>
            </div>
            <TicketLiveChat ticket={ticket} />
          </div>
        )}

        {/* VIEW 2: DETAILS TAB */}
        {activeTab === 'details' && (
          <>
            {/* Section A: Customer & Location Cards (Prominent Light Lavender & Violet Border) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Box 1: Informasi Pelanggan dengan Tombol WhatsApp tepat di sebelah Telepon */}
              <div className="p-5 rounded-2xl border-2 border-[#D8CCF3] dark:border-[#3B1D78] bg-white dark:bg-[#1f113a] shadow-sm space-y-3.5">
                <div className="flex items-center justify-between border-b border-[#D8CCF3]/60 dark:border-[#3B1D78] pb-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#3B1D78] dark:text-[#E9E1FF]">
                    <User className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                    <span>Informasi Pelanggan</span>
                  </div>
                  <span className="text-[10.5px] font-mono px-2 py-0.5 bg-[#E9E1FF] dark:bg-[#3B1D78] text-[#3B1D78] dark:text-[#E9E1FF] font-bold rounded-lg border border-[#D8CCF3] dark:border-[#5B35B1]">
                    ID: {ticket.idCustomer || ticket.customerId || '-'}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <div className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3]">Nama Pelanggan</div>
                    <div className="font-bold text-base text-[#21183A] dark:text-white">
                      {ticket.customerName || ticket.endUserName || '-'}
                    </div>
                  </div>

                  {/* Customer Phone with [WhatsApp Pelanggan] directly next to it */}
                  <div className="p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3] dark:border-[#3B1D78]">
                    <div className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3] mb-1.5 font-medium">
                      Nomor Telepon & WhatsApp Pelanggan:
                    </div>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                        <span className="font-mono font-bold text-sm text-[#21183A] dark:text-white">
                          {ticket.customerPhone || 'Tidak ada nomor'}
                        </span>
                      </div>

                      {ticket.customerPhone ? (
                        <div className="flex items-center gap-1.5">
                          <a
                            href={`tel:${ticket.customerPhone}`}
                            className="p-1.5 bg-white dark:bg-[#1f113a] hover:bg-[#E9E1FF] text-[#3B1D78] dark:text-[#E9E1FF] rounded-lg text-xs font-bold flex items-center gap-1 border border-[#D8CCF3] dark:border-[#3B1D78] transition-colors"
                            title="Telepon Langsung"
                          >
                            <Phone className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="hidden sm:inline">Panggil</span>
                          </a>

                          <button
                            type="button"
                            onClick={() => {
                              if (waUrlObj.url) {
                                window.open(waUrlObj.url, '_blank', 'noopener,noreferrer');
                              } else {
                                onOpenWhatsApp(ticket);
                              }
                            }}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-all cursor-pointer"
                            title="Chat WhatsApp Pelanggan"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>WhatsApp Pelanggan</span>
                          </button>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400 italic">Nomor belum terisi</span>
                      )}
                    </div>

                    {ticket.customerContact2 && (
                      <div className="mt-2.5 pt-2 border-t border-[#D8CCF3]/60 dark:border-[#3B1D78] flex items-center justify-between text-[11px]">
                        <span className="text-[#756B8D] dark:text-[#D8CCF3]">Kontak Cadangan:</span>
                        <span className="font-mono font-medium text-[#21183A] dark:text-white">{ticket.customerContact2}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Box 2: Informasi Lokasi & Navigasi (Interactive Google Maps on Click) */}
              <div className="p-5 rounded-2xl border-2 border-[#D8CCF3] dark:border-[#3B1D78] bg-white dark:bg-[#1f113a] shadow-sm space-y-3.5">
                <div className="flex items-center justify-between border-b border-[#D8CCF3]/60 dark:border-[#3B1D78] pb-2.5">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#3B1D78] dark:text-[#E9E1FF]">
                    <MapPin className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                    <span>📍 Informasi Lokasi & Alamat</span>
                  </div>
                  <span className="text-[11px] font-semibold text-[#756B8D] dark:text-[#D8CCF3]">
                    Area: {ticket.area || '-'}
                  </span>
                </div>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <div className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3]">Cluster / Komplek</div>
                    <div className="font-bold text-sm text-[#21183A] dark:text-white">
                      {ticket.clusterName || 'Non-Cluster'}
                    </div>
                  </div>

                  {/* Clickable Address box for Google Maps search */}
                  <div
                    onClick={handleOpenMaps}
                    className="group cursor-pointer p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3] dark:border-[#5B35B1] hover:border-[#5B35B1] hover:bg-[#E9E1FF] dark:hover:bg-[#3B1D78]/70 transition-all text-[#21183A] dark:text-[#F5F1FF] leading-relaxed font-medium shadow-2xs"
                    title="Klik alamat untuk membuka Google Maps"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="text-[10px] font-bold uppercase tracking-wider text-[#756B8D] dark:text-[#D8CCF3] mb-0.5">
                          Alamat Lengkap & Jalan
                        </div>
                        <div className="font-bold text-xs text-[#3B1D78] dark:text-[#E9E1FF]">
                          {ticket.streetName || ticket.address || 'Alamat belum diinput'}
                        </div>
                        {ticket.streetAlternatif && (
                          <div className="text-[11px] text-[#756B8D] dark:text-[#D8CCF3] mt-1.5 italic border-t border-[#D8CCF3]/60 dark:border-[#3B1D78] pt-1">
                            Patokan: {ticket.streetAlternatif}
                          </div>
                        )}
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-white dark:bg-[#1a0f30] text-[#5B35B1] dark:text-[#E9E1FF] font-bold text-[11px] border border-[#D8CCF3] dark:border-[#3B1D78] shrink-0 flex items-center gap-1 group-hover:scale-105 transition-transform shadow-2xs">
                        <Navigation className="w-3.5 h-3.5 text-[#5B35B1]" />
                        <span>Maps</span>
                      </span>
                    </div>
                    <div className="text-[10px] text-[#8064D9] dark:text-[#D8CCF3] font-semibold mt-2 flex items-center gap-1">
                      <span>📍 Klik alamat untuk membuka rute Google Maps ↗</span>
                    </div>
                  </div>

                  {/* Actions: Salin Alamat & Buka Google Maps */}
                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="flex-1 py-2 px-3 bg-white dark:bg-[#1f113a] hover:bg-[#E9E1FF] dark:hover:bg-[#3B1D78] text-[#3B1D78] dark:text-[#E9E1FF] rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors border border-[#D8CCF3] dark:border-[#3B1D78] cursor-pointer"
                    >
                      {copiedAddress ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedAddress ? 'Tersalin' : 'Salin Alamat'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleOpenMaps}
                      className="flex-1 py-2 px-3 bg-[#5B35B1] hover:bg-[#3B1D78] text-white rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Buka Google Maps</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Section B: Detail Teknis & Infrastruktur Jaringan */}
            <div className="p-5 rounded-2xl border-2 border-[#D8CCF3] dark:border-[#3B1D78] bg-white dark:bg-[#1f113a] shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-[#D8CCF3]/60 dark:border-[#3B1D78] pb-2.5">
                <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#3B1D78] dark:text-[#E9E1FF]">
                  <Radio className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                  <span>Infrastruktur Jaringan & Detail Pekerjaan</span>
                </div>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#E9E1FF] dark:bg-[#3B1D78] text-[#3B1D78] dark:text-[#E9E1FF] font-bold border border-[#D8CCF3] dark:border-[#5B35B1]">
                  {ticket.ticketCategory || 'FTTH Service'}
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3]/70 dark:border-[#3B1D78]">
                  <div className="text-[10.5px] text-[#756B8D] dark:text-[#D8CCF3]">Kode FDT</div>
                  <div className="font-mono font-bold text-[#21183A] dark:text-white mt-0.5">
                    {ticket.fdtCode || '-'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3]/70 dark:border-[#3B1D78]">
                  <div className="text-[10.5px] text-[#756B8D] dark:text-[#D8CCF3]">Kode FAT & Port</div>
                  <div className="font-mono font-bold text-[#5B35B1] dark:text-[#8064D9] mt-0.5">
                    {ticket.fatCode || '-'}{ticket.fatPort ? ` (Port ${ticket.fatPort})` : ''}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3]/70 dark:border-[#3B1D78]">
                  <div className="text-[10.5px] text-[#756B8D] dark:text-[#D8CCF3]">Vendor Kontraktor</div>
                  <div className="font-bold text-[#21183A] dark:text-white mt-0.5 truncate">
                    {ticket.contactorName || ticket.contractorName || '-'}
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-[#F5F1FF] dark:bg-[#251247] border border-[#D8CCF3]/70 dark:border-[#3B1D78]">
                  <div className="text-[10.5px] text-[#756B8D] dark:text-[#D8CCF3]">Leader / Korlap</div>
                  <div className="font-bold text-[#21183A] dark:text-white mt-0.5 truncate">
                    {ticket.leaderName || ticket.corlapName || '-'}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* VIEW 3: REPORT TAB */}
        {activeTab === 'report' && (
          <div className="p-5 sm:p-6 rounded-2xl border-2 border-[#D8CCF3] dark:border-[#3B1D78] bg-white dark:bg-[#1f113a] shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-[#D8CCF3]/60 dark:border-[#3B1D78] pb-3">
              <div className="flex items-center gap-2">
                <Wrench className="w-5 h-5 text-[#5B35B1] dark:text-[#8064D9]" />
                <h3 className="font-bold text-sm sm:text-base text-[#3B1D78] dark:text-[#E9E1FF]">
                  Laporan Teknis Lapangan (Technical Report)
                </h3>
              </div>
              <span className="text-xs text-[#756B8D] dark:text-[#D8CCF3]">
                Wajib diisi sebelum dinyatakan Selesai
              </span>
            </div>

            <form onSubmit={handleSaveReport} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                    Pengukuran Redaman OPM (dBm) *
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={opticalPowerDbm}
                      onChange={e => setOpticalPowerDbm(e.target.value)}
                      placeholder="misal: -18.5"
                      className="w-full px-3 py-2.5 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] font-mono font-bold text-[#21183A] dark:text-white focus:ring-2 focus:ring-[#5B35B1]"
                    />
                    <div className="absolute inset-y-0 right-3 flex items-center text-[#756B8D] font-bold">
                      dBm
                    </div>
                  </div>
                  <div className="text-[10.5px] text-[#756B8D] dark:text-[#D8CCF3] mt-1">Standar ideal instalasi: -16.0 dBm s/d -24.0 dBm</div>
                </div>

                <div>
                  <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                    Nomor Seri Perangkat (ONT / Router SN)
                  </label>
                  <input
                    type="text"
                    value={deviceSerialNumber}
                    onChange={e => setDeviceSerialNumber(e.target.value)}
                    placeholder="SN: HWTC12345678"
                    className="w-full px-3 py-2.5 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] font-mono text-[#21183A] dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                    Kategori Masalah / Pekerjaan
                  </label>
                  <select
                    value={mainCategory}
                    onChange={e => setMainCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] text-[#21183A] dark:text-white font-medium"
                  >
                    {rootCauseCategories.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                    Hasil Pekerjaan (Work Result)
                  </label>
                  <select
                    value={workResult}
                    onChange={e => setWorkResult(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] text-[#21183A] dark:text-white font-medium"
                  >
                    {workResultsList.map(r => (
                      <option key={r} value={r}>{r}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                  Material yang Digunakan
                </label>
                <input
                  type="text"
                  value={usedMaterials}
                  onChange={e => setUsedMaterials(e.target.value)}
                  placeholder="misal: Dropcore 120m, 1 Roset, 2 Fast Connector"
                  className="w-full px-3 py-2 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] text-[#21183A] dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1">
                  Catatan Teknis & Penjelasan Lapangan
                </label>
                <textarea
                  rows={3}
                  value={technicalDescription}
                  onChange={e => setTechnicalDescription(e.target.value)}
                  placeholder="Rincian proses pekerjaan, kendala di lapangan, atau pesan kepada Dispatch..."
                  className="w-full px-3 py-2.5 rounded-xl border border-[#D8CCF3] dark:border-[#3B1D78] bg-[#F5F1FF] dark:bg-[#251247] text-[#21183A] dark:text-white resize-none"
                />
              </div>

              {/* Photo Attachment Picker */}
              <div>
                <label className="block font-semibold text-[#21183A] dark:text-[#F5F1FF] mb-1.5">
                  Dokumentasi Foto Pengerjaan / Bukti ONT Menyala
                </label>
                <div className="flex items-center gap-3">
                  <label className="px-3.5 py-2 bg-[#E9E1FF] dark:bg-[#3B1D78] hover:bg-[#D8CCF3] text-[#3B1D78] dark:text-[#E9E1FF] rounded-xl font-bold cursor-pointer flex items-center gap-2 border border-[#D8CCF3] dark:border-[#5B35B1] transition-colors">
                    <Camera className="w-4 h-4 text-[#5B35B1] dark:text-[#8064D9]" />
                    <span>Ambil / Pilih Foto</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </label>
                  {photoPreview && (
                    <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Foto terlampir
                    </span>
                  )}
                </div>
                {photoPreview && (
                  <div className="mt-2.5 relative inline-block rounded-xl overflow-hidden border border-[#D8CCF3] dark:border-[#3B1D78] shadow-sm">
                    <img src={photoPreview} alt="Bukti Pengerjaan" className="w-32 h-24 object-cover" />
                    <button
                      type="button"
                      onClick={() => setPhotoPreview(null)}
                      className="absolute top-1 right-1 p-1 bg-black/60 text-white rounded-full text-[10px]"
                      title="Hapus Foto"
                    >
                      &times;
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#3B1D78] hover:bg-[#5B35B1] text-white font-bold rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan Draft Laporan</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>

      {/* Sticky Bottom Actions Bar (Responsively arranged: [Otw Lokasi] [Live Chat], then [Buka Tiket Lain / Tandai Selesai]) */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-white/95 dark:bg-[#1a0f30]/95 backdrop-blur-md border-t border-[#D8CCF3] dark:border-[#3B1D78] p-3 sm:px-8 shadow-xl flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 max-w-5xl mx-auto">
        {/* Row 1: Quick Actions [Otw Lokasi] [Live Chat] */}
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-2">
          {/* Button Otw Lokasi: updates status AND opens Google Maps */}
          <button
            type="button"
            onClick={handleOtwLokasiWithMaps}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs bg-[#5B35B1] hover:bg-[#3B1D78] text-white shadow-xs transition-colors cursor-pointer"
            title="Update status En Route dan buka rute Google Maps"
          >
            <Navigation className="w-4 h-4" />
            <span>Otw Lokasi</span>
          </button>

          {/* Button Live Chat: switches to live chat */}
          <button
            type="button"
            onClick={() => setActiveTab(activeTab === 'chat' ? 'details' : 'chat')}
            className={`flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs border transition-colors cursor-pointer ${
              activeTab === 'chat'
                ? 'bg-[#3B1D78] text-white border-[#3B1D78]'
                : 'bg-[#E9E1FF] dark:bg-[#3B1D78]/60 text-[#3B1D78] dark:text-[#E9E1FF] border-[#D8CCF3] dark:border-[#5B35B1] hover:bg-[#D8CCF3]'
            }`}
            title="Buka Live Chat Koordinasi Dispatch"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Live Chat</span>
            {unreadChatCount > 0 && (
              <span className="px-1.5 py-0.2 bg-rose-600 text-white text-[10px] font-bold rounded-full">
                {unreadChatCount}
              </span>
            )}
          </button>
        </div>

        {/* Row 2: Secondary / Completion Actions */}
        <div className="grid grid-cols-2 sm:flex sm:items-center gap-2">
          {/* Button Kembali ke Daftar Tiket */}
          <button
            type="button"
            onClick={onBack}
            className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl font-bold text-xs bg-white dark:bg-[#1f113a] text-[#756B8D] dark:text-[#D8CCF3] border border-[#D8CCF3] dark:border-[#3B1D78] hover:bg-[#E9E1FF]/50 transition-colors cursor-pointer"
            title="Kembali ke Daftar WO"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Daftar WO</span>
          </button>

          {/* Button Tandai Selesai */}
          <button
            type="button"
            onClick={handleMarkCompleted}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Tandai Selesai</span>
          </button>
        </div>
      </div>
    </div>
  );
};
